internalType: "CompilationUnit"
startPosition {
  line: 1
  col: 1
}
endPosition {
  line: 173
  col: 2
}
children {
  internalType: "ImportDeclaration"
  startPosition {
    line: 1
    col: 1
  }
  endPosition {
    line: 1
    col: 20
  }
  token: "java.io.File"
}
children {
  internalType: "ImportDeclaration"
  startPosition {
    line: 2
    col: 1
  }
  endPosition {
    line: 2
    col: 37
  }
  token: "java.io.FileNotFoundException"
}
children {
  internalType: "ImportDeclaration"
  startPosition {
    line: 3
    col: 1
  }
  endPosition {
    line: 3
    col: 27
  }
  token: "java.util.ArrayList"
}
children {
  internalType: "ImportDeclaration"
  startPosition {
    line: 4
    col: 1
  }
  endPosition {
    line: 4
    col: 25
  }
  token: "java.util.HashMap"
}
children {
  internalType: "ImportDeclaration"
  startPosition {
    line: 5
    col: 1
  }
  endPosition {
    line: 5
    col: 26
  }
  token: "java.util.Iterator"
}
children {
  internalType: "ImportDeclaration"
  startPosition {
    line: 6
    col: 1
  }
  endPosition {
    line: 6
    col: 21
  }
  token: "java.util.Map"
}
children {
  internalType: "ImportDeclaration"
  startPosition {
    line: 7
    col: 1
  }
  endPosition {
    line: 7
    col: 25
  }
  token: "java.util.Scanner"
}
children {
  internalType: "ImportDeclaration"
  startPosition {
    line: 9
    col: 1
  }
  endPosition {
    line: 9
    col: 32
  }
  token: "javax.swing.JFileChooser"
}
children {
  internalType: "ImportDeclaration"
  startPosition {
    line: 10
    col: 1
  }
  endPosition {
    line: 10
    col: 29
  }
  token: "javax.swing.UIManager"
}
children {
  internalType: "ClassOrInterfaceDeclaration"
  startPosition {
    line: 13
    col: 1
  }
  endPosition {
    line: 173
    col: 1
  }
  children {
    internalType: "Modifier"
    startPosition {
      line: 13
      col: 1
    }
    endPosition {
      line: 173
      col: 1
    }
    token: "public"
  }
  children {
    internalType: "SimpleName"
    startPosition {
      line: 13
      col: 14
    }
    endPosition {
      line: 13
      col: 22
    }
    token: "WordCount"
  }
  children {
    internalType: "MethodDeclaration"
    startPosition {
      line: 15
      col: 5
    }
    endPosition {
      line: 17
      col: 5
    }
    children {
      internalType: "Modifier"
      startPosition {
        line: 15
        col: 5
      }
      endPosition {
        line: 17
        col: 5
      }
      token: "public"
    }
    children {
      internalType: "Modifier"
      startPosition {
        line: 15
        col: 5
      }
      endPosition {
        line: 17
        col: 5
      }
      token: "static"
    }
    children {
      internalType: "SimpleName"
      startPosition {
        line: 15
        col: 24
      }
      endPosition {
        line: 15
        col: 27
      }
      token: "main"
    }
    children {
      internalType: "Parameter"
      roles: Argument
      startPosition {
        line: 15
        col: 29
      }
      endPosition {
        line: 15
        col: 41
      }
      children {
        internalType: "ArrayType"
        roles: Argument
        startPosition {
          line: 15
          col: 29
        }
        endPosition {
          line: 15
          col: 36
        }
        children {
          internalType: "ClassOrInterfaceType"
          roles: Type
          roles: Argument
          startPosition {
            line: 15
            col: 29
          }
          endPosition {
            line: 15
            col: 34
          }
          children {
            internalType: "SimpleName"
            roles: Type
            roles: Argument
            startPosition {
              line: 15
              col: 29
            }
            endPosition {
              line: 15
              col: 34
            }
            token: "String"
          }
          token: "Type:String"
        }
      }
      children {
        internalType: "SimpleName"
        roles: Argument
        roles: Identifier
        startPosition {
          line: 15
          col: 38
        }
        endPosition {
          line: 15
          col: 41
        }
        token: "args"
      }
    }
    children {
      internalType: "VoidType"
      startPosition {
        line: 15
        col: 19
      }
      endPosition {
        line: 15
        col: 22
      }
      token: "void"
    }
    children {
      internalType: "BlockStmt"
      startPosition {
        line: 15
        col: 44
      }
      endPosition {
        line: 17
        col: 5
      }
      children {
        internalType: "ExpressionStmt"
        startPosition {
          line: 16
          col: 9
        }
        endPosition {
          line: 16
          col: 27
        }
        children {
          internalType: "MethodCallExpr"
          startPosition {
            line: 16
            col: 9
          }
          endPosition {
            line: 16
            col: 26
          }
          children {
            internalType: "SimpleName"
            roles: Call
            startPosition {
              line: 16
              col: 9
            }
            endPosition {
              line: 16
              col: 24
            }
            token: "countWordsViaGUI"
          }
          token: "MethodCall:countWordsViaGUI"
        }
      }
    }
  }
  children {
    internalType: "MethodDeclaration"
    startPosition {
      line: 22
      col: 5
    }
    endPosition {
      line: 45
      col: 5
    }
    children {
      internalType: "Modifier"
      startPosition {
        line: 22
        col: 5
      }
      endPosition {
        line: 45
        col: 5
      }
      token: "public"
    }
    children {
      internalType: "Modifier"
      startPosition {
        line: 22
        col: 5
      }
      endPosition {
        line: 45
        col: 5
      }
      token: "static"
    }
    children {
      internalType: "SimpleName"
      startPosition {
        line: 22
        col: 24
      }
      endPosition {
        line: 22
        col: 39
      }
      token: "countWordsViaGUI"
    }
    children {
      internalType: "VoidType"
      startPosition {
        line: 22
        col: 19
      }
      endPosition {
        line: 22
        col: 22
      }
      token: "void"
    }
    children {
      internalType: "BlockStmt"
      startPosition {
        line: 22
        col: 43
      }
      endPosition {
        line: 45
        col: 5
      }
      children {
        internalType: "ExpressionStmt"
        startPosition {
          line: 23
          col: 9
        }
        endPosition {
          line: 23
          col: 25
        }
        children {
          internalType: "MethodCallExpr"
          startPosition {
            line: 23
            col: 9
          }
          endPosition {
            line: 23
            col: 24
          }
          children {
            internalType: "SimpleName"
            roles: Call
            startPosition {
              line: 23
              col: 9
            }
            endPosition {
              line: 23
              col: 22
            }
            token: "setLookAndFeel"
          }
          token: "MethodCall:setLookAndFeel"
        }
      }
      children {
        internalType: "TryStmt"
        startPosition {
          line: 24
          col: 9
        }
        endPosition {
          line: 44
          col: 9
        }
        children {
          internalType: "BlockStmt"
          roles: Try
          startPosition {
            line: 24
            col: 13
          }
          endPosition {
            line: 41
            col: 9
          }
          children {
            internalType: "ExpressionStmt"
            roles: Try
            startPosition {
              line: 25
              col: 13
            }
            endPosition {
              line: 25
              col: 49
            }
            children {
              internalType: "VariableDeclarationExpr"
              roles: Try
              startPosition {
                line: 25
                col: 13
              }
              endPosition {
                line: 25
                col: 48
              }
              children {
                internalType: "VariableDeclarator"
                roles: Declaration
                roles: Try
                startPosition {
                  line: 25
                  col: 21
                }
                endPosition {
                  line: 25
                  col: 48
                }
                children {
                  internalType: "ClassOrInterfaceType"
                  roles: Type
                  roles: Declaration
                  roles: Try
                  startPosition {
                    line: 25
                    col: 13
                  }
                  endPosition {
                    line: 25
                    col: 19
                  }
                  children {
                    internalType: "SimpleName"
                    roles: Type
                    roles: Declaration
                    roles: Try
                    startPosition {
                      line: 25
                      col: 13
                    }
                    endPosition {
                      line: 25
                      col: 19
                    }
                    token: "Scanner"
                  }
                  token: "Type:Scanner"
                }
                children {
                  internalType: "SimpleName"
                  roles: Identifier
                  roles: Declaration
                  roles: Try
                  startPosition {
                    line: 25
                    col: 21
                  }
                  endPosition {
                    line: 25
                    col: 23
                  }
                  token: "key"
                }
                children {
                  internalType: "ObjectCreationExpr"
                  roles: Declaration
                  roles: Try
                  startPosition {
                    line: 25
                    col: 27
                  }
                  endPosition {
                    line: 25
                    col: 48
                  }
                  children {
                    internalType: "ClassOrInterfaceType"
                    roles: Type
                    roles: Declaration
                    roles: Try
                    startPosition {
                      line: 25
                      col: 31
                    }
                    endPosition {
                      line: 25
                      col: 37
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Type
                      roles: Declaration
                      roles: Try
                      startPosition {
                        line: 25
                        col: 31
                      }
                      endPosition {
                        line: 25
                        col: 37
                      }
                      token: "Scanner"
                    }
                    token: "Type:Scanner"
                  }
                  children {
                    internalType: "FieldAccessExpr"
                    roles: Argument
                    roles: Declaration
                    roles: Try
                    startPosition {
                      line: 25
                      col: 39
                    }
                    endPosition {
                      line: 25
                      col: 47
                    }
                    children {
                      internalType: "NameExpr"
                      roles: Argument
                      roles: Scope
                      roles: Declaration
                      roles: Try
                      startPosition {
                        line: 25
                        col: 39
                      }
                      endPosition {
                        line: 25
                        col: 44
                      }
                      children {
                        internalType: "SimpleName"
                        roles: Argument
                        roles: Scope
                        roles: Declaration
                        roles: Try
                        startPosition {
                          line: 25
                          col: 39
                        }
                        endPosition {
                          line: 25
                          col: 44
                        }
                        token: "System"
                      }
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Argument
                      roles: Identifier
                      roles: Declaration
                      roles: Try
                      startPosition {
                        line: 25
                        col: 46
                      }
                      endPosition {
                        line: 25
                        col: 47
                      }
                      token: "in"
                    }
                    token: "FieldAccess:in"
                  }
                }
              }
            }
          }
          children {
            internalType: "DoStmt"
            roles: Try
            startPosition {
              line: 26
              col: 13
            }
            endPosition {
              line: 39
              col: 67
            }
            children {
              internalType: "BlockStmt"
              roles: Try
              startPosition {
                line: 26
                col: 16
              }
              endPosition {
                line: 39
                col: 13
              }
              children {
                internalType: "ExpressionStmt"
                roles: Try
                startPosition {
                  line: 27
                  col: 17
                }
                endPosition {
                  line: 27
                  col: 66
                }
                children {
                  internalType: "MethodCallExpr"
                  roles: Try
                  startPosition {
                    line: 27
                    col: 17
                  }
                  endPosition {
                    line: 27
                    col: 65
                  }
                  children {
                    internalType: "FieldAccessExpr"
                    roles: Callee
                    roles: Try
                    startPosition {
                      line: 27
                      col: 17
                    }
                    endPosition {
                      line: 27
                      col: 26
                    }
                    children {
                      internalType: "NameExpr"
                      roles: Callee
                      roles: Scope
                      roles: Try
                      startPosition {
                        line: 27
                        col: 17
                      }
                      endPosition {
                        line: 27
                        col: 22
                      }
                      children {
                        internalType: "SimpleName"
                        roles: Callee
                        roles: Scope
                        roles: Try
                        startPosition {
                          line: 27
                          col: 17
                        }
                        endPosition {
                          line: 27
                          col: 22
                        }
                        token: "System"
                      }
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Callee
                      roles: Identifier
                      roles: Try
                      startPosition {
                        line: 27
                        col: 24
                      }
                      endPosition {
                        line: 27
                        col: 26
                      }
                      token: "out"
                    }
                    token: "FieldAccess:out"
                  }
                  children {
                    internalType: "SimpleName"
                    roles: Call
                    roles: Try
                    startPosition {
                      line: 27
                      col: 28
                    }
                    endPosition {
                      line: 27
                      col: 34
                    }
                    token: "println"
                  }
                  children {
                    internalType: "StringLiteralExpr"
                    roles: Argument
                    roles: Try
                    startPosition {
                      line: 27
                      col: 36
                    }
                    endPosition {
                      line: 27
                      col: 64
                    }
                    token: "Opening GUI to choose file."
                  }
                  token: "MethodCall:println"
                }
              }
              children {
                internalType: "ExpressionStmt"
                roles: Try
                startPosition {
                  line: 28
                  col: 17
                }
                endPosition {
                  line: 28
                  col: 61
                }
                children {
                  internalType: "VariableDeclarationExpr"
                  roles: Try
                  startPosition {
                    line: 28
                    col: 17
                  }
                  endPosition {
                    line: 28
                    col: 60
                  }
                  children {
                    internalType: "VariableDeclarator"
                    roles: Declaration
                    roles: Try
                    startPosition {
                      line: 28
                      col: 25
                    }
                    endPosition {
                      line: 28
                      col: 60
                    }
                    children {
                      internalType: "ClassOrInterfaceType"
                      roles: Type
                      roles: Declaration
                      roles: Try
                      startPosition {
                        line: 28
                        col: 17
                      }
                      endPosition {
                        line: 28
                        col: 23
                      }
                      children {
                        internalType: "SimpleName"
                        roles: Type
                        roles: Declaration
                        roles: Try
                        startPosition {
                          line: 28
                          col: 17
                        }
                        endPosition {
                          line: 28
                          col: 23
                        }
                        token: "Scanner"
                      }
                      token: "Type:Scanner"
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Identifier
                      roles: Declaration
                      roles: Try
                      startPosition {
                        line: 28
                        col: 25
                      }
                      endPosition {
                        line: 28
                        col: 35
                      }
                      token: "fileScanner"
                    }
                    children {
                      internalType: "ObjectCreationExpr"
                      roles: Declaration
                      roles: Try
                      startPosition {
                        line: 28
                        col: 39
                      }
                      endPosition {
                        line: 28
                        col: 60
                      }
                      children {
                        internalType: "ClassOrInterfaceType"
                        roles: Type
                        roles: Declaration
                        roles: Try
                        startPosition {
                          line: 28
                          col: 43
                        }
                        endPosition {
                          line: 28
                          col: 49
                        }
                        children {
                          internalType: "SimpleName"
                          roles: Type
                          roles: Declaration
                          roles: Try
                          startPosition {
                            line: 28
                            col: 43
                          }
                          endPosition {
                            line: 28
                            col: 49
                          }
                          token: "Scanner"
                        }
                        token: "Type:Scanner"
                      }
                      children {
                        internalType: "MethodCallExpr"
                        roles: Argument
                        roles: Declaration
                        roles: Try
                        startPosition {
                          line: 28
                          col: 51
                        }
                        endPosition {
                          line: 28
                          col: 59
                        }
                        children {
                          internalType: "SimpleName"
                          roles: Call
                          roles: Argument
                          roles: Declaration
                          roles: Try
                          startPosition {
                            line: 28
                            col: 51
                          }
                          endPosition {
                            line: 28
                            col: 57
                          }
                          token: "getFile"
                        }
                        token: "MethodCall:getFile"
                      }
                    }
                  }
                }
              }
              children {
                internalType: "ExpressionStmt"
                roles: Try
                startPosition {
                  line: 29
                  col: 17
                }
                endPosition {
                  line: 29
                  col: 47
                }
                children {
                  internalType: "VariableDeclarationExpr"
                  roles: Try
                  startPosition {
                    line: 29
                    col: 17
                  }
                  endPosition {
                    line: 29
                    col: 46
                  }
                  children {
                    internalType: "VariableDeclarator"
                    roles: Declaration
                    roles: Try
                    startPosition {
                      line: 29
                      col: 27
                    }
                    endPosition {
                      line: 29
                      col: 46
                    }
                    children {
                      internalType: "ClassOrInterfaceType"
                      roles: Type
                      roles: Declaration
                      roles: Try
                      startPosition {
                        line: 29
                        col: 17
                      }
                      endPosition {
                        line: 29
                        col: 25
                      }
                      children {
                        internalType: "SimpleName"
                        roles: Type
                        roles: Declaration
                        roles: Try
                        startPosition {
                          line: 29
                          col: 17
                        }
                        endPosition {
                          line: 29
                          col: 25
                        }
                        token: "Stopwatch"
                      }
                      token: "Type:Stopwatch"
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Identifier
                      roles: Declaration
                      roles: Try
                      startPosition {
                        line: 29
                        col: 27
                      }
                      endPosition {
                        line: 29
                        col: 28
                      }
                      token: "st"
                    }
                    children {
                      internalType: "ObjectCreationExpr"
                      roles: Declaration
                      roles: Try
                      startPosition {
                        line: 29
                        col: 32
                      }
                      endPosition {
                        line: 29
                        col: 46
                      }
                      children {
                        internalType: "ClassOrInterfaceType"
                        roles: Type
                        roles: Declaration
                        roles: Try
                        startPosition {
                          line: 29
                          col: 36
                        }
                        endPosition {
                          line: 29
                          col: 44
                        }
                        children {
                          internalType: "SimpleName"
                          roles: Type
                          roles: Declaration
                          roles: Try
                          startPosition {
                            line: 29
                            col: 36
                          }
                          endPosition {
                            line: 29
                            col: 44
                          }
                          token: "Stopwatch"
                        }
                        token: "Type:Stopwatch"
                      }
                    }
                  }
                }
              }
              children {
                internalType: "ExpressionStmt"
                roles: Try
                startPosition {
                  line: 30
                  col: 17
                }
                endPosition {
                  line: 30
                  col: 27
                }
                children {
                  internalType: "MethodCallExpr"
                  roles: Try
                  startPosition {
                    line: 30
                    col: 17
                  }
                  endPosition {
                    line: 30
                    col: 26
                  }
                  children {
                    internalType: "NameExpr"
                    roles: Callee
                    roles: Try
                    startPosition {
                      line: 30
                      col: 17
                    }
                    endPosition {
                      line: 30
                      col: 18
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Callee
                      roles: Try
                      startPosition {
                        line: 30
                        col: 17
                      }
                      endPosition {
                        line: 30
                        col: 18
                      }
                      token: "st"
                    }
                  }
                  children {
                    internalType: "SimpleName"
                    roles: Call
                    roles: Try
                    startPosition {
                      line: 30
                      col: 20
                    }
                    endPosition {
                      line: 30
                      col: 24
                    }
                    token: "start"
                  }
                  token: "MethodCall:start"
                }
              }
              children {
                internalType: "ExpressionStmt"
                roles: Try
                startPosition {
                  line: 31
                  col: 17
                }
                endPosition {
                  line: 31
                  col: 79
                }
                children {
                  internalType: "VariableDeclarationExpr"
                  roles: Try
                  startPosition {
                    line: 31
                    col: 17
                  }
                  endPosition {
                    line: 31
                    col: 78
                  }
                  children {
                    internalType: "VariableDeclarator"
                    roles: Declaration
                    roles: Try
                    startPosition {
                      line: 31
                      col: 35
                    }
                    endPosition {
                      line: 31
                      col: 78
                    }
                    children {
                      internalType: "ClassOrInterfaceType"
                      roles: Type
                      roles: Declaration
                      roles: Try
                      startPosition {
                        line: 31
                        col: 17
                      }
                      endPosition {
                        line: 31
                        col: 33
                      }
                      children {
                        internalType: "SimpleName"
                        roles: Type
                        roles: Declaration
                        roles: Try
                        startPosition {
                          line: 31
                          col: 17
                        }
                        endPosition {
                          line: 31
                          col: 25
                        }
                        token: "ArrayList"
                      }
                      children {
                        internalType: "ClassOrInterfaceType"
                        roles: Type
                        roles: Argument
                        roles: Declaration
                        roles: Try
                        startPosition {
                          line: 31
                          col: 27
                        }
                        endPosition {
                          line: 31
                          col: 32
                        }
                        children {
                          internalType: "SimpleName"
                          roles: Type
                          roles: Argument
                          roles: Declaration
                          roles: Try
                          startPosition {
                            line: 31
                            col: 27
                          }
                          endPosition {
                            line: 31
                            col: 32
                          }
                          token: "String"
                        }
                        token: "Type:String"
                      }
                      token: "Type:ArrayList"
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Identifier
                      roles: Declaration
                      roles: Try
                      startPosition {
                        line: 31
                        col: 35
                      }
                      endPosition {
                        line: 31
                        col: 39
                      }
                      token: "words"
                    }
                    children {
                      internalType: "MethodCallExpr"
                      roles: Declaration
                      roles: Try
                      startPosition {
                        line: 31
                        col: 43
                      }
                      endPosition {
                        line: 31
                        col: 78
                      }
                      children {
                        internalType: "SimpleName"
                        roles: Call
                        roles: Declaration
                        roles: Try
                        startPosition {
                          line: 31
                          col: 43
                        }
                        endPosition {
                          line: 31
                          col: 65
                        }
                        token: "countWordsWithArrayList"
                      }
                      children {
                        internalType: "NameExpr"
                        roles: Argument
                        roles: Declaration
                        roles: Try
                        startPosition {
                          line: 31
                          col: 67
                        }
                        endPosition {
                          line: 31
                          col: 77
                        }
                        children {
                          internalType: "SimpleName"
                          roles: Argument
                          roles: Declaration
                          roles: Try
                          startPosition {
                            line: 31
                            col: 67
                          }
                          endPosition {
                            line: 31
                            col: 77
                          }
                          token: "fileScanner"
                        }
                      }
                      token: "MethodCall:countWordsWithArrayList"
                    }
                  }
                }
              }
              children {
                internalType: "ExpressionStmt"
                roles: Try
                startPosition {
                  line: 32
                  col: 17
                }
                endPosition {
                  line: 32
                  col: 26
                }
                children {
                  internalType: "MethodCallExpr"
                  roles: Try
                  startPosition {
                    line: 32
                    col: 17
                  }
                  endPosition {
                    line: 32
                    col: 25
                  }
                  children {
                    internalType: "NameExpr"
                    roles: Callee
                    roles: Try
                    startPosition {
                      line: 32
                      col: 17
                    }
                    endPosition {
                      line: 32
                      col: 18
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Callee
                      roles: Try
                      startPosition {
                        line: 32
                        col: 17
                      }
                      endPosition {
                        line: 32
                        col: 18
                      }
                      token: "st"
                    }
                  }
                  children {
                    internalType: "SimpleName"
                    roles: Call
                    roles: Try
                    startPosition {
                      line: 32
                      col: 20
                    }
                    endPosition {
                      line: 32
                      col: 23
                    }
                    token: "stop"
                  }
                  token: "MethodCall:stop"
                }
              }
              children {
                internalType: "ExpressionStmt"
                roles: Try
                startPosition {
                  line: 33
                  col: 17
                }
                endPosition {
                  line: 33
                  col: 59
                }
                children {
                  internalType: "MethodCallExpr"
                  roles: Try
                  startPosition {
                    line: 33
                    col: 17
                  }
                  endPosition {
                    line: 33
                    col: 58
                  }
                  children {
                    internalType: "FieldAccessExpr"
                    roles: Callee
                    roles: Try
                    startPosition {
                      line: 33
                      col: 17
                    }
                    endPosition {
                      line: 33
                      col: 26
                    }
                    children {
                      internalType: "NameExpr"
                      roles: Callee
                      roles: Scope
                      roles: Try
                      startPosition {
                        line: 33
                        col: 17
                      }
                      endPosition {
                        line: 33
                        col: 22
                      }
                      children {
                        internalType: "SimpleName"
                        roles: Callee
                        roles: Scope
                        roles: Try
                        startPosition {
                          line: 33
                          col: 17
                        }
                        endPosition {
                          line: 33
                          col: 22
                        }
                        token: "System"
                      }
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Callee
                      roles: Identifier
                      roles: Try
                      startPosition {
                        line: 33
                        col: 24
                      }
                      endPosition {
                        line: 33
                        col: 26
                      }
                      token: "out"
                    }
                    token: "FieldAccess:out"
                  }
                  children {
                    internalType: "SimpleName"
                    roles: Call
                    roles: Try
                    startPosition {
                      line: 33
                      col: 28
                    }
                    endPosition {
                      line: 33
                      col: 34
                    }
                    token: "println"
                  }
                  children {
                    internalType: "BinaryExpr"
                    roles: Argument
                    roles: Try
                    startPosition {
                      line: 33
                      col: 36
                    }
                    endPosition {
                      line: 33
                      col: 57
                    }
                    children {
                      internalType: "StringLiteralExpr"
                      roles: Argument
                      roles: Try
                      roles: Left
                      startPosition {
                        line: 33
                        col: 36
                      }
                      endPosition {
                        line: 33
                        col: 52
                      }
                      token: "time to count: "
                    }
                    children {
                      internalType: "NameExpr"
                      roles: Argument
                      roles: Right
                      roles: Try
                      startPosition {
                        line: 33
                        col: 56
                      }
                      endPosition {
                        line: 33
                        col: 57
                      }
                      children {
                        internalType: "SimpleName"
                        roles: Argument
                        roles: Right
                        roles: Try
                        startPosition {
                          line: 33
                          col: 56
                        }
                        endPosition {
                          line: 33
                          col: 57
                        }
                        token: "st"
                      }
                    }
                    token: "PLUS"
                  }
                  token: "MethodCall:println"
                }
              }
              children {
                internalType: "ExpressionStmt"
                roles: Try
                startPosition {
                  line: 34
                  col: 17
                }
                endPosition {
                  line: 34
                  col: 71
                }
                children {
                  internalType: "MethodCallExpr"
                  roles: Try
                  startPosition {
                    line: 34
                    col: 17
                  }
                  endPosition {
                    line: 34
                    col: 70
                  }
                  children {
                    internalType: "FieldAccessExpr"
                    roles: Callee
                    roles: Try
                    startPosition {
                      line: 34
                      col: 17
                    }
                    endPosition {
                      line: 34
                      col: 26
                    }
                    children {
                      internalType: "NameExpr"
                      roles: Callee
                      roles: Scope
                      roles: Try
                      startPosition {
                        line: 34
                        col: 17
                      }
                      endPosition {
                        line: 34
                        col: 22
                      }
                      children {
                        internalType: "SimpleName"
                        roles: Callee
                        roles: Scope
                        roles: Try
                        startPosition {
                          line: 34
                          col: 17
                        }
                        endPosition {
                          line: 34
                          col: 22
                        }
                        token: "System"
                      }
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Callee
                      roles: Identifier
                      roles: Try
                      startPosition {
                        line: 34
                        col: 24
                      }
                      endPosition {
                        line: 34
                        col: 26
                      }
                      token: "out"
                    }
                    token: "FieldAccess:out"
                  }
                  children {
                    internalType: "SimpleName"
                    roles: Call
                    roles: Try
                    startPosition {
                      line: 34
                      col: 28
                    }
                    endPosition {
                      line: 34
                      col: 32
                    }
                    token: "print"
                  }
                  children {
                    internalType: "StringLiteralExpr"
                    roles: Argument
                    roles: Try
                    startPosition {
                      line: 34
                      col: 34
                    }
                    endPosition {
                      line: 34
                      col: 69
                    }
                    token: "Enter number of words to display: "
                  }
                  token: "MethodCall:print"
                }
              }
              children {
                internalType: "ExpressionStmt"
                roles: Try
                startPosition {
                  line: 35
                  col: 17
                }
                endPosition {
                  line: 35
                  col: 70
                }
                children {
                  internalType: "VariableDeclarationExpr"
                  roles: Try
                  startPosition {
                    line: 35
                    col: 17
                  }
                  endPosition {
                    line: 35
                    col: 69
                  }
                  children {
                    internalType: "VariableDeclarator"
                    roles: Declaration
                    roles: Try
                    startPosition {
                      line: 35
                      col: 21
                    }
                    endPosition {
                      line: 35
                      col: 69
                    }
                    children {
                      internalType: "PrimitiveType"
                      roles: Type
                      roles: Declaration
                      roles: Try
                      startPosition {
                        line: 35
                        col: 17
                      }
                      endPosition {
                        line: 35
                        col: 19
                      }
                      token: "int"
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Identifier
                      roles: Declaration
                      roles: Try
                      startPosition {
                        line: 35
                        col: 21
                      }
                      endPosition {
                        line: 35
                        col: 34
                      }
                      token: "numWordsToShow"
                    }
                    children {
                      internalType: "MethodCallExpr"
                      roles: Declaration
                      roles: Try
                      startPosition {
                        line: 35
                        col: 38
                      }
                      endPosition {
                        line: 35
                        col: 69
                      }
                      children {
                        internalType: "NameExpr"
                        roles: Callee
                        roles: Declaration
                        roles: Try
                        startPosition {
                          line: 35
                          col: 38
                        }
                        endPosition {
                          line: 35
                          col: 44
                        }
                        children {
                          internalType: "SimpleName"
                          roles: Callee
                          roles: Declaration
                          roles: Try
                          startPosition {
                            line: 35
                            col: 38
                          }
                          endPosition {
                            line: 35
                            col: 44
                          }
                          token: "Integer"
                        }
                      }
                      children {
                        internalType: "SimpleName"
                        roles: Call
                        roles: Declaration
                        roles: Try
                        startPosition {
                          line: 35
                          col: 46
                        }
                        endPosition {
                          line: 35
                          col: 53
                        }
                        token: "parseInt"
                      }
                      children {
                        internalType: "MethodCallExpr"
                        roles: Argument
                        roles: Declaration
                        roles: Try
                        startPosition {
                          line: 35
                          col: 55
                        }
                        endPosition {
                          line: 35
                          col: 68
                        }
                        children {
                          internalType: "NameExpr"
                          roles: Argument
                          roles: Callee
                          roles: Declaration
                          roles: Try
                          startPosition {
                            line: 35
                            col: 55
                          }
                          endPosition {
                            line: 35
                            col: 57
                          }
                          children {
                            internalType: "SimpleName"
                            roles: Argument
                            roles: Callee
                            roles: Declaration
                            roles: Try
                            startPosition {
                              line: 35
                              col: 55
                            }
                            endPosition {
                              line: 35
                              col: 57
                            }
                            token: "key"
                          }
                        }
                        children {
                          internalType: "SimpleName"
                          roles: Call
                          roles: Argument
                          roles: Declaration
                          roles: Try
                          startPosition {
                            line: 35
                            col: 59
                          }
                          endPosition {
                            line: 35
                            col: 66
                          }
                          token: "nextLine"
                        }
                        token: "MethodCall:nextLine"
                      }
                      token: "MethodCall:parseInt"
                    }
                  }
                }
              }
              children {
                internalType: "ExpressionStmt"
                roles: Try
                startPosition {
                  line: 36
                  col: 17
                }
                endPosition {
                  line: 36
                  col: 49
                }
                children {
                  internalType: "MethodCallExpr"
                  roles: Try
                  startPosition {
                    line: 36
                    col: 17
                  }
                  endPosition {
                    line: 36
                    col: 48
                  }
                  children {
                    internalType: "SimpleName"
                    roles: Call
                    roles: Try
                    startPosition {
                      line: 36
                      col: 17
                    }
                    endPosition {
                      line: 36
                      col: 25
                    }
                    token: "showWords"
                  }
                  children {
                    internalType: "NameExpr"
                    roles: Argument
                    roles: Try
                    startPosition {
                      line: 36
                      col: 27
                    }
                    endPosition {
                      line: 36
                      col: 31
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Argument
                      roles: Try
                      startPosition {
                        line: 36
                        col: 27
                      }
                      endPosition {
                        line: 36
                        col: 31
                      }
                      token: "words"
                    }
                  }
                  children {
                    internalType: "NameExpr"
                    roles: Argument
                    roles: Try
                    startPosition {
                      line: 36
                      col: 34
                    }
                    endPosition {
                      line: 36
                      col: 47
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Argument
                      roles: Try
                      startPosition {
                        line: 36
                        col: 34
                      }
                      endPosition {
                        line: 36
                        col: 47
                      }
                      token: "numWordsToShow"
                    }
                  }
                  token: "MethodCall:showWords"
                }
              }
              children {
                internalType: "ExpressionStmt"
                roles: Try
                startPosition {
                  line: 37
                  col: 17
                }
                endPosition {
                  line: 37
                  col: 36
                }
                children {
                  internalType: "MethodCallExpr"
                  roles: Try
                  startPosition {
                    line: 37
                    col: 17
                  }
                  endPosition {
                    line: 37
                    col: 35
                  }
                  children {
                    internalType: "NameExpr"
                    roles: Callee
                    roles: Try
                    startPosition {
                      line: 37
                      col: 17
                    }
                    endPosition {
                      line: 37
                      col: 27
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Callee
                      roles: Try
                      startPosition {
                        line: 37
                        col: 17
                      }
                      endPosition {
                        line: 37
                        col: 27
                      }
                      token: "fileScanner"
                    }
                  }
                  children {
                    internalType: "SimpleName"
                    roles: Call
                    roles: Try
                    startPosition {
                      line: 37
                      col: 29
                    }
                    endPosition {
                      line: 37
                      col: 33
                    }
                    token: "close"
                  }
                  token: "MethodCall:close"
                }
              }
              children {
                internalType: "ExpressionStmt"
                roles: Try
                startPosition {
                  line: 38
                  col: 17
                }
                endPosition {
                  line: 38
                  col: 60
                }
                children {
                  internalType: "MethodCallExpr"
                  roles: Try
                  startPosition {
                    line: 38
                    col: 17
                  }
                  endPosition {
                    line: 38
                    col: 59
                  }
                  children {
                    internalType: "FieldAccessExpr"
                    roles: Callee
                    roles: Try
                    startPosition {
                      line: 38
                      col: 17
                    }
                    endPosition {
                      line: 38
                      col: 26
                    }
                    children {
                      internalType: "NameExpr"
                      roles: Callee
                      roles: Scope
                      roles: Try
                      startPosition {
                        line: 38
                        col: 17
                      }
                      endPosition {
                        line: 38
                        col: 22
                      }
                      children {
                        internalType: "SimpleName"
                        roles: Callee
                        roles: Scope
                        roles: Try
                        startPosition {
                          line: 38
                          col: 17
                        }
                        endPosition {
                          line: 38
                          col: 22
                        }
                        token: "System"
                      }
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Callee
                      roles: Identifier
                      roles: Try
                      startPosition {
                        line: 38
                        col: 24
                      }
                      endPosition {
                        line: 38
                        col: 26
                      }
                      token: "out"
                    }
                    token: "FieldAccess:out"
                  }
                  children {
                    internalType: "SimpleName"
                    roles: Call
                    roles: Try
                    startPosition {
                      line: 38
                      col: 28
                    }
                    endPosition {
                      line: 38
                      col: 32
                    }
                    token: "print"
                  }
                  children {
                    internalType: "StringLiteralExpr"
                    roles: Argument
                    roles: Try
                    startPosition {
                      line: 38
                      col: 34
                    }
                    endPosition {
                      line: 38
                      col: 58
                    }
                    token: "Perform another count? "
                  }
                  token: "MethodCall:print"
                }
              }
            }
            children {
              internalType: "BinaryExpr"
              roles: Condition
              roles: Try
              startPosition {
                line: 39
                col: 21
              }
              endPosition {
                line: 39
                col: 65
              }
              children {
                internalType: "MethodCallExpr"
                roles: Condition
                roles: Try
                roles: Left
                startPosition {
                  line: 39
                  col: 21
                }
                endPosition {
                  line: 39
                  col: 58
                }
                children {
                  internalType: "MethodCallExpr"
                  roles: Callee
                  roles: Condition
                  roles: Try
                  roles: Left
                  startPosition {
                    line: 39
                    col: 21
                  }
                  endPosition {
                    line: 39
                    col: 48
                  }
                  children {
                    internalType: "MethodCallExpr"
                    roles: Callee
                    roles: Condition
                    roles: Try
                    roles: Left
                    startPosition {
                      line: 39
                      col: 21
                    }
                    endPosition {
                      line: 39
                      col: 34
                    }
                    children {
                      internalType: "NameExpr"
                      roles: Callee
                      roles: Condition
                      roles: Try
                      roles: Left
                      startPosition {
                        line: 39
                        col: 21
                      }
                      endPosition {
                        line: 39
                        col: 23
                      }
                      children {
                        internalType: "SimpleName"
                        roles: Callee
                        roles: Condition
                        roles: Try
                        roles: Left
                        startPosition {
                          line: 39
                          col: 21
                        }
                        endPosition {
                          line: 39
                          col: 23
                        }
                        token: "key"
                      }
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Call
                      roles: Callee
                      roles: Condition
                      roles: Try
                      roles: Left
                      startPosition {
                        line: 39
                        col: 25
                      }
                      endPosition {
                        line: 39
                        col: 32
                      }
                      token: "nextLine"
                    }
                    token: "MethodCall:nextLine"
                  }
                  children {
                    internalType: "SimpleName"
                    roles: Call
                    roles: Callee
                    roles: Condition
                    roles: Try
                    roles: Left
                    startPosition {
                      line: 39
                      col: 36
                    }
                    endPosition {
                      line: 39
                      col: 46
                    }
                    token: "toLowerCase"
                  }
                  token: "MethodCall:toLowerCase"
                }
                children {
                  internalType: "SimpleName"
                  roles: Call
                  roles: Condition
                  roles: Try
                  roles: Left
                  startPosition {
                    line: 39
                    col: 50
                  }
                  endPosition {
                    line: 39
                    col: 55
                  }
                  token: "charAt"
                }
                children {
                  internalType: "IntegerLiteralExpr"
                  roles: Argument
                  roles: Condition
                  roles: Try
                  roles: Left
                  startPosition {
                    line: 39
                    col: 57
                  }
                  endPosition {
                    line: 39
                    col: 57
                  }
                }
                token: "MethodCall:charAt"
              }
              children {
                internalType: "CharLiteralExpr"
                roles: Right
                roles: Condition
                roles: Try
                startPosition {
                  line: 39
                  col: 63
                }
                endPosition {
                  line: 39
                  col: 65
                }
                token: "y"
              }
              token: "EQUALS"
            }
          }
          children {
            internalType: "ExpressionStmt"
            roles: Try
            startPosition {
              line: 40
              col: 13
            }
            endPosition {
              line: 40
              col: 24
            }
            children {
              internalType: "MethodCallExpr"
              roles: Try
              startPosition {
                line: 40
                col: 13
              }
              endPosition {
                line: 40
                col: 23
              }
              children {
                internalType: "NameExpr"
                roles: Callee
                roles: Try
                startPosition {
                  line: 40
                  col: 13
                }
                endPosition {
                  line: 40
                  col: 15
                }
                children {
                  internalType: "SimpleName"
                  roles: Callee
                  roles: Try
                  startPosition {
                    line: 40
                    col: 13
                  }
                  endPosition {
                    line: 40
                    col: 15
                  }
                  token: "key"
                }
              }
              children {
                internalType: "SimpleName"
                roles: Call
                roles: Try
                startPosition {
                  line: 40
                  col: 17
                }
                endPosition {
                  line: 40
                  col: 21
                }
                token: "close"
              }
              token: "MethodCall:close"
            }
          }
        }
        children {
          internalType: "CatchClause"
          startPosition {
            line: 42
            col: 9
          }
          endPosition {
            line: 44
            col: 9
          }
          children {
            internalType: "Parameter"
            roles: Argument
            startPosition {
              line: 42
              col: 15
            }
            endPosition {
              line: 42
              col: 37
            }
            children {
              internalType: "ClassOrInterfaceType"
              roles: Type
              roles: Argument
              startPosition {
                line: 42
                col: 15
              }
              endPosition {
                line: 42
                col: 35
              }
              children {
                internalType: "SimpleName"
                roles: Type
                roles: Argument
                startPosition {
                  line: 42
                  col: 15
                }
                endPosition {
                  line: 42
                  col: 35
                }
                token: "FileNotFoundException"
              }
              token: "Type:FileNotFoundException"
            }
            children {
              internalType: "SimpleName"
              roles: Argument
              roles: Identifier
              startPosition {
                line: 42
                col: 37
              }
              endPosition {
                line: 42
                col: 37
              }
              token: "e"
            }
          }
          children {
            internalType: "BlockStmt"
            roles: Catch
            startPosition {
              line: 42
              col: 40
            }
            endPosition {
              line: 44
              col: 9
            }
            children {
              internalType: "ExpressionStmt"
              roles: Catch
              startPosition {
                line: 43
                col: 13
              }
              endPosition {
                line: 43
                col: 90
              }
              children {
                internalType: "MethodCallExpr"
                roles: Catch
                startPosition {
                  line: 43
                  col: 13
                }
                endPosition {
                  line: 43
                  col: 89
                }
                children {
                  internalType: "FieldAccessExpr"
                  roles: Callee
                  roles: Catch
                  startPosition {
                    line: 43
                    col: 13
                  }
                  endPosition {
                    line: 43
                    col: 22
                  }
                  children {
                    internalType: "NameExpr"
                    roles: Callee
                    roles: Scope
                    roles: Catch
                    startPosition {
                      line: 43
                      col: 13
                    }
                    endPosition {
                      line: 43
                      col: 18
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Callee
                      roles: Scope
                      roles: Catch
                      startPosition {
                        line: 43
                        col: 13
                      }
                      endPosition {
                        line: 43
                        col: 18
                      }
                      token: "System"
                    }
                  }
                  children {
                    internalType: "SimpleName"
                    roles: Callee
                    roles: Identifier
                    roles: Catch
                    startPosition {
                      line: 43
                      col: 20
                    }
                    endPosition {
                      line: 43
                      col: 22
                    }
                    token: "out"
                  }
                  token: "FieldAccess:out"
                }
                children {
                  internalType: "SimpleName"
                  roles: Call
                  roles: Catch
                  startPosition {
                    line: 43
                    col: 24
                  }
                  endPosition {
                    line: 43
                    col: 30
                  }
                  token: "println"
                }
                children {
                  internalType: "BinaryExpr"
                  roles: Argument
                  roles: Catch
                  startPosition {
                    line: 43
                    col: 32
                  }
                  endPosition {
                    line: 43
                    col: 88
                  }
                  children {
                    internalType: "StringLiteralExpr"
                    roles: Argument
                    roles: Catch
                    roles: Left
                    startPosition {
                      line: 43
                      col: 32
                    }
                    endPosition {
                      line: 43
                      col: 84
                    }
                    token: "Problem reading the data file. Exiting the program."
                  }
                  children {
                    internalType: "NameExpr"
                    roles: Argument
                    roles: Right
                    roles: Catch
                    startPosition {
                      line: 43
                      col: 88
                    }
                    endPosition {
                      line: 43
                      col: 88
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Argument
                      roles: Right
                      roles: Catch
                      startPosition {
                        line: 43
                        col: 88
                      }
                      endPosition {
                        line: 43
                        col: 88
                      }
                      token: "e"
                    }
                  }
                  token: "PLUS"
                }
                token: "MethodCall:println"
              }
            }
          }
        }
      }
    }
  }
  children {
    internalType: "MethodDeclaration"
    startPosition {
      line: 49
      col: 5
    }
    endPosition {
      line: 55
      col: 5
    }
    children {
      internalType: "Modifier"
      startPosition {
        line: 49
        col: 5
      }
      endPosition {
        line: 55
        col: 5
      }
      token: "private"
    }
    children {
      internalType: "Modifier"
      startPosition {
        line: 49
        col: 5
      }
      endPosition {
        line: 55
        col: 5
      }
      token: "static"
    }
    children {
      internalType: "SimpleName"
      startPosition {
        line: 49
        col: 38
      }
      endPosition {
        line: 49
        col: 60
      }
      token: "countWordsWithArrayList"
    }
    children {
      internalType: "Parameter"
      roles: Argument
      startPosition {
        line: 49
        col: 62
      }
      endPosition {
        line: 49
        col: 80
      }
      children {
        internalType: "ClassOrInterfaceType"
        roles: Type
        roles: Argument
        startPosition {
          line: 49
          col: 62
        }
        endPosition {
          line: 49
          col: 68
        }
        children {
          internalType: "SimpleName"
          roles: Type
          roles: Argument
          startPosition {
            line: 49
            col: 62
          }
          endPosition {
            line: 49
            col: 68
          }
          token: "Scanner"
        }
        token: "Type:Scanner"
      }
      children {
        internalType: "SimpleName"
        roles: Argument
        roles: Identifier
        startPosition {
          line: 49
          col: 70
        }
        endPosition {
          line: 49
          col: 80
        }
        token: "fileScanner"
      }
    }
    children {
      internalType: "ClassOrInterfaceType"
      roles: Type
      startPosition {
        line: 49
        col: 20
      }
      endPosition {
        line: 49
        col: 36
      }
      children {
        internalType: "SimpleName"
        roles: Type
        startPosition {
          line: 49
          col: 20
        }
        endPosition {
          line: 49
          col: 28
        }
        token: "ArrayList"
      }
      children {
        internalType: "ClassOrInterfaceType"
        roles: Type
        roles: Argument
        startPosition {
          line: 49
          col: 30
        }
        endPosition {
          line: 49
          col: 35
        }
        children {
          internalType: "SimpleName"
          roles: Type
          roles: Argument
          startPosition {
            line: 49
            col: 30
          }
          endPosition {
            line: 49
            col: 35
          }
          token: "String"
        }
        token: "Type:String"
      }
      token: "Type:ArrayList"
    }
    children {
      internalType: "BlockStmt"
      startPosition {
        line: 49
        col: 83
      }
      endPosition {
        line: 55
        col: 5
      }
      children {
        internalType: "ExpressionStmt"
        startPosition {
          line: 52
          col: 9
        }
        endPosition {
          line: 52
          col: 65
        }
        children {
          internalType: "MethodCallExpr"
          startPosition {
            line: 52
            col: 9
          }
          endPosition {
            line: 52
            col: 64
          }
          children {
            internalType: "FieldAccessExpr"
            roles: Callee
            startPosition {
              line: 52
              col: 9
            }
            endPosition {
              line: 52
              col: 18
            }
            children {
              internalType: "NameExpr"
              roles: Callee
              roles: Scope
              startPosition {
                line: 52
                col: 9
              }
              endPosition {
                line: 52
                col: 14
              }
              children {
                internalType: "SimpleName"
                roles: Callee
                roles: Scope
                startPosition {
                  line: 52
                  col: 9
                }
                endPosition {
                  line: 52
                  col: 14
                }
                token: "System"
              }
            }
            children {
              internalType: "SimpleName"
              roles: Callee
              roles: Identifier
              startPosition {
                line: 52
                col: 16
              }
              endPosition {
                line: 52
                col: 18
              }
              token: "out"
            }
            token: "FieldAccess:out"
          }
          children {
            internalType: "SimpleName"
            roles: Call
            startPosition {
              line: 52
              col: 20
            }
            endPosition {
              line: 52
              col: 26
            }
            token: "println"
          }
          children {
            internalType: "BinaryExpr"
            roles: Argument
            startPosition {
              line: 52
              col: 28
            }
            endPosition {
              line: 52
              col: 63
            }
            children {
              internalType: "StringLiteralExpr"
              roles: Argument
              roles: Left
              startPosition {
                line: 52
                col: 28
              }
              endPosition {
                line: 52
                col: 52
              }
              token: "Total number of words: "
            }
            children {
              internalType: "NameExpr"
              roles: Argument
              roles: Right
              startPosition {
                line: 52
                col: 56
              }
              endPosition {
                line: 52
                col: 63
              }
              children {
                internalType: "SimpleName"
                roles: Argument
                roles: Right
                startPosition {
                  line: 52
                  col: 56
                }
                endPosition {
                  line: 52
                  col: 63
                }
                token: "numWords"
              }
            }
            token: "PLUS"
          }
          token: "MethodCall:println"
        }
      }
      children {
        internalType: "ExpressionStmt"
        startPosition {
          line: 53
          col: 9
        }
        endPosition {
          line: 53
          col: 73
        }
        children {
          internalType: "MethodCallExpr"
          startPosition {
            line: 53
            col: 9
          }
          endPosition {
            line: 53
            col: 72
          }
          children {
            internalType: "FieldAccessExpr"
            roles: Callee
            startPosition {
              line: 53
              col: 9
            }
            endPosition {
              line: 53
              col: 18
            }
            children {
              internalType: "NameExpr"
              roles: Callee
              roles: Scope
              startPosition {
                line: 53
                col: 9
              }
              endPosition {
                line: 53
                col: 14
              }
              children {
                internalType: "SimpleName"
                roles: Callee
                roles: Scope
                startPosition {
                  line: 53
                  col: 9
                }
                endPosition {
                  line: 53
                  col: 14
                }
                token: "System"
              }
            }
            children {
              internalType: "SimpleName"
              roles: Callee
              roles: Identifier
              startPosition {
                line: 53
                col: 16
              }
              endPosition {
                line: 53
                col: 18
              }
              token: "out"
            }
            token: "FieldAccess:out"
          }
          children {
            internalType: "SimpleName"
            roles: Call
            startPosition {
              line: 53
              col: 20
            }
            endPosition {
              line: 53
              col: 26
            }
            token: "println"
          }
          children {
            internalType: "BinaryExpr"
            roles: Argument
            startPosition {
              line: 53
              col: 28
            }
            endPosition {
              line: 53
              col: 71
            }
            children {
              internalType: "StringLiteralExpr"
              roles: Argument
              roles: Left
              startPosition {
                line: 53
                col: 28
              }
              endPosition {
                line: 53
                col: 55
              }
              token: "number of distincy words: "
            }
            children {
              internalType: "MethodCallExpr"
              roles: Argument
              roles: Right
              startPosition {
                line: 53
                col: 59
              }
              endPosition {
                line: 53
                col: 71
              }
              children {
                internalType: "NameExpr"
                roles: Argument
                roles: Callee
                roles: Right
                startPosition {
                  line: 53
                  col: 59
                }
                endPosition {
                  line: 53
                  col: 64
                }
                children {
                  internalType: "SimpleName"
                  roles: Argument
                  roles: Callee
                  roles: Right
                  startPosition {
                    line: 53
                    col: 59
                  }
                  endPosition {
                    line: 53
                    col: 64
                  }
                  token: "result"
                }
              }
              children {
                internalType: "SimpleName"
                roles: Call
                roles: Argument
                roles: Right
                startPosition {
                  line: 53
                  col: 66
                }
                endPosition {
                  line: 53
                  col: 69
                }
                token: "size"
              }
              token: "MethodCall:size"
            }
            token: "PLUS"
          }
          token: "MethodCall:println"
        }
      }
      children {
        internalType: "ReturnStmt"
        startPosition {
          line: 54
          col: 9
        }
        endPosition {
          line: 54
          col: 22
        }
        children {
          internalType: "NameExpr"
          startPosition {
            line: 54
            col: 16
          }
          endPosition {
            line: 54
            col: 21
          }
          children {
            internalType: "SimpleName"
            startPosition {
              line: 54
              col: 16
            }
            endPosition {
              line: 54
              col: 21
            }
            token: "result"
          }
        }
      }
    }
  }
  children {
    internalType: "MethodDeclaration"
    startPosition {
      line: 59
      col: 5
    }
    endPosition {
      line: 65
      col: 5
    }
    children {
      internalType: "Modifier"
      startPosition {
        line: 59
        col: 5
      }
      endPosition {
        line: 65
        col: 5
      }
      token: "private"
    }
    children {
      internalType: "Modifier"
      startPosition {
        line: 59
        col: 5
      }
      endPosition {
        line: 65
        col: 5
      }
      token: "static"
    }
    children {
      internalType: "SimpleName"
      startPosition {
        line: 59
        col: 41
      }
      endPosition {
        line: 59
        col: 57
      }
      token: "countWordsWithMap"
    }
    children {
      internalType: "Parameter"
      roles: Argument
      startPosition {
        line: 59
        col: 59
      }
      endPosition {
        line: 59
        col: 77
      }
      children {
        internalType: "ClassOrInterfaceType"
        roles: Type
        roles: Argument
        startPosition {
          line: 59
          col: 59
        }
        endPosition {
          line: 59
          col: 65
        }
        children {
          internalType: "SimpleName"
          roles: Type
          roles: Argument
          startPosition {
            line: 59
            col: 59
          }
          endPosition {
            line: 59
            col: 65
          }
          token: "Scanner"
        }
        token: "Type:Scanner"
      }
      children {
        internalType: "SimpleName"
        roles: Argument
        roles: Identifier
        startPosition {
          line: 59
          col: 67
        }
        endPosition {
          line: 59
          col: 77
        }
        token: "fileScanner"
      }
    }
    children {
      internalType: "ClassOrInterfaceType"
      roles: Type
      startPosition {
        line: 59
        col: 20
      }
      endPosition {
        line: 59
        col: 39
      }
      children {
        internalType: "SimpleName"
        roles: Type
        startPosition {
          line: 59
          col: 20
        }
        endPosition {
          line: 59
          col: 22
        }
        token: "Map"
      }
      children {
        internalType: "ClassOrInterfaceType"
        roles: Type
        roles: Argument
        startPosition {
          line: 59
          col: 24
        }
        endPosition {
          line: 59
          col: 29
        }
        children {
          internalType: "SimpleName"
          roles: Type
          roles: Argument
          startPosition {
            line: 59
            col: 24
          }
          endPosition {
            line: 59
            col: 29
          }
          token: "String"
        }
        token: "Type:String"
      }
      children {
        internalType: "ClassOrInterfaceType"
        roles: Type
        roles: Argument
        startPosition {
          line: 59
          col: 32
        }
        endPosition {
          line: 59
          col: 38
        }
        children {
          internalType: "SimpleName"
          roles: Type
          roles: Argument
          startPosition {
            line: 59
            col: 32
          }
          endPosition {
            line: 59
            col: 38
          }
          token: "Integer"
        }
        token: "Type:Integer"
      }
      token: "Type:Map"
    }
    children {
      internalType: "BlockStmt"
      startPosition {
        line: 59
        col: 80
      }
      endPosition {
        line: 65
        col: 5
      }
      children {
        internalType: "ExpressionStmt"
        startPosition {
          line: 62
          col: 9
        }
        endPosition {
          line: 62
          col: 65
        }
        children {
          internalType: "MethodCallExpr"
          startPosition {
            line: 62
            col: 9
          }
          endPosition {
            line: 62
            col: 64
          }
          children {
            internalType: "FieldAccessExpr"
            roles: Callee
            startPosition {
              line: 62
              col: 9
            }
            endPosition {
              line: 62
              col: 18
            }
            children {
              internalType: "NameExpr"
              roles: Callee
              roles: Scope
              startPosition {
                line: 62
                col: 9
              }
              endPosition {
                line: 62
                col: 14
              }
              children {
                internalType: "SimpleName"
                roles: Callee
                roles: Scope
                startPosition {
                  line: 62
                  col: 9
                }
                endPosition {
                  line: 62
                  col: 14
                }
                token: "System"
              }
            }
            children {
              internalType: "SimpleName"
              roles: Callee
              roles: Identifier
              startPosition {
                line: 62
                col: 16
              }
              endPosition {
                line: 62
                col: 18
              }
              token: "out"
            }
            token: "FieldAccess:out"
          }
          children {
            internalType: "SimpleName"
            roles: Call
            startPosition {
              line: 62
              col: 20
            }
            endPosition {
              line: 62
              col: 26
            }
            token: "println"
          }
          children {
            internalType: "BinaryExpr"
            roles: Argument
            startPosition {
              line: 62
              col: 28
            }
            endPosition {
              line: 62
              col: 63
            }
            children {
              internalType: "StringLiteralExpr"
              roles: Argument
              roles: Left
              startPosition {
                line: 62
                col: 28
              }
              endPosition {
                line: 62
                col: 52
              }
              token: "Total number of words: "
            }
            children {
              internalType: "NameExpr"
              roles: Argument
              roles: Right
              startPosition {
                line: 62
                col: 56
              }
              endPosition {
                line: 62
                col: 63
              }
              children {
                internalType: "SimpleName"
                roles: Argument
                roles: Right
                startPosition {
                  line: 62
                  col: 56
                }
                endPosition {
                  line: 62
                  col: 63
                }
                token: "numWords"
              }
            }
            token: "PLUS"
          }
          token: "MethodCall:println"
        }
      }
      children {
        internalType: "ExpressionStmt"
        startPosition {
          line: 63
          col: 9
        }
        endPosition {
          line: 63
          col: 73
        }
        children {
          internalType: "MethodCallExpr"
          startPosition {
            line: 63
            col: 9
          }
          endPosition {
            line: 63
            col: 72
          }
          children {
            internalType: "FieldAccessExpr"
            roles: Callee
            startPosition {
              line: 63
              col: 9
            }
            endPosition {
              line: 63
              col: 18
            }
            children {
              internalType: "NameExpr"
              roles: Callee
              roles: Scope
              startPosition {
                line: 63
                col: 9
              }
              endPosition {
                line: 63
                col: 14
              }
              children {
                internalType: "SimpleName"
                roles: Callee
                roles: Scope
                startPosition {
                  line: 63
                  col: 9
                }
                endPosition {
                  line: 63
                  col: 14
                }
                token: "System"
              }
            }
            children {
              internalType: "SimpleName"
              roles: Callee
              roles: Identifier
              startPosition {
                line: 63
                col: 16
              }
              endPosition {
                line: 63
                col: 18
              }
              token: "out"
            }
            token: "FieldAccess:out"
          }
          children {
            internalType: "SimpleName"
            roles: Call
            startPosition {
              line: 63
              col: 20
            }
            endPosition {
              line: 63
              col: 26
            }
            token: "println"
          }
          children {
            internalType: "BinaryExpr"
            roles: Argument
            startPosition {
              line: 63
              col: 28
            }
            endPosition {
              line: 63
              col: 71
            }
            children {
              internalType: "StringLiteralExpr"
              roles: Argument
              roles: Left
              startPosition {
                line: 63
                col: 28
              }
              endPosition {
                line: 63
                col: 55
              }
              token: "number of distincy words: "
            }
            children {
              internalType: "MethodCallExpr"
              roles: Argument
              roles: Right
              startPosition {
                line: 63
                col: 59
              }
              endPosition {
                line: 63
                col: 71
              }
              children {
                internalType: "NameExpr"
                roles: Argument
                roles: Callee
                roles: Right
                startPosition {
                  line: 63
                  col: 59
                }
                endPosition {
                  line: 63
                  col: 64
                }
                children {
                  internalType: "SimpleName"
                  roles: Argument
                  roles: Callee
                  roles: Right
                  startPosition {
                    line: 63
                    col: 59
                  }
                  endPosition {
                    line: 63
                    col: 64
                  }
                  token: "result"
                }
              }
              children {
                internalType: "SimpleName"
                roles: Call
                roles: Argument
                roles: Right
                startPosition {
                  line: 63
                  col: 66
                }
                endPosition {
                  line: 63
                  col: 69
                }
                token: "size"
              }
              token: "MethodCall:size"
            }
            token: "PLUS"
          }
          token: "MethodCall:println"
        }
      }
      children {
        internalType: "ReturnStmt"
        startPosition {
          line: 64
          col: 9
        }
        endPosition {
          line: 64
          col: 22
        }
        children {
          internalType: "NameExpr"
          startPosition {
            line: 64
            col: 16
          }
          endPosition {
            line: 64
            col: 21
          }
          children {
            internalType: "SimpleName"
            startPosition {
              line: 64
              col: 16
            }
            endPosition {
              line: 64
              col: 21
            }
            token: "result"
          }
        }
      }
    }
  }
  children {
    internalType: "MethodDeclaration"
    startPosition {
      line: 68
      col: 5
    }
    endPosition {
      line: 71
      col: 5
    }
    children {
      internalType: "Modifier"
      startPosition {
        line: 68
        col: 5
      }
      endPosition {
        line: 71
        col: 5
      }
      token: "private"
    }
    children {
      internalType: "Modifier"
      startPosition {
        line: 68
        col: 5
      }
      endPosition {
        line: 71
        col: 5
      }
      token: "static"
    }
    children {
      internalType: "SimpleName"
      startPosition {
        line: 68
        col: 25
      }
      endPosition {
        line: 68
        col: 33
      }
      token: "showWords"
    }
    children {
      internalType: "Parameter"
      roles: Argument
      startPosition {
        line: 68
        col: 35
      }
      endPosition {
        line: 68
        col: 57
      }
      children {
        internalType: "ClassOrInterfaceType"
        roles: Type
        roles: Argument
        startPosition {
          line: 68
          col: 35
        }
        endPosition {
          line: 68
          col: 51
        }
        children {
          internalType: "SimpleName"
          roles: Type
          roles: Argument
          startPosition {
            line: 68
            col: 35
          }
          endPosition {
            line: 68
            col: 43
          }
          token: "ArrayList"
        }
        children {
          internalType: "ClassOrInterfaceType"
          roles: Type
          roles: Argument
          startPosition {
            line: 68
            col: 45
          }
          endPosition {
            line: 68
            col: 50
          }
          children {
            internalType: "SimpleName"
            roles: Type
            roles: Argument
            startPosition {
              line: 68
              col: 45
            }
            endPosition {
              line: 68
              col: 50
            }
            token: "String"
          }
          token: "Type:String"
        }
        token: "Type:ArrayList"
      }
      children {
        internalType: "SimpleName"
        roles: Argument
        roles: Identifier
        startPosition {
          line: 68
          col: 53
        }
        endPosition {
          line: 68
          col: 57
        }
        token: "words"
      }
    }
    children {
      internalType: "Parameter"
      roles: Argument
      startPosition {
        line: 68
        col: 60
      }
      endPosition {
        line: 68
        col: 77
      }
      children {
        internalType: "PrimitiveType"
        roles: Argument
        startPosition {
          line: 68
          col: 60
        }
        endPosition {
          line: 68
          col: 62
        }
        token: "int"
      }
      children {
        internalType: "SimpleName"
        roles: Argument
        roles: Identifier
        startPosition {
          line: 68
          col: 64
        }
        endPosition {
          line: 68
          col: 77
        }
        token: "numWordsToShow"
      }
    }
    children {
      internalType: "VoidType"
      startPosition {
        line: 68
        col: 20
      }
      endPosition {
        line: 68
        col: 23
      }
      token: "void"
    }
    children {
      internalType: "BlockStmt"
      startPosition {
        line: 68
        col: 80
      }
      endPosition {
        line: 71
        col: 5
      }
      children {
        internalType: "ForStmt"
        startPosition {
          line: 69
          col: 9
        }
        endPosition {
          line: 70
          col: 45
        }
        children {
          internalType: "VariableDeclarationExpr"
          roles: Initialization
          startPosition {
            line: 69
            col: 13
          }
          endPosition {
            line: 69
            col: 21
          }
          children {
            internalType: "VariableDeclarator"
            roles: Initialization
            roles: Declaration
            startPosition {
              line: 69
              col: 17
            }
            endPosition {
              line: 69
              col: 21
            }
            children {
              internalType: "PrimitiveType"
              roles: Type
              roles: Initialization
              roles: Declaration
              startPosition {
                line: 69
                col: 13
              }
              endPosition {
                line: 69
                col: 15
              }
              token: "int"
            }
            children {
              internalType: "SimpleName"
              roles: Initialization
              roles: Identifier
              roles: Declaration
              startPosition {
                line: 69
                col: 17
              }
              endPosition {
                line: 69
                col: 17
              }
              token: "i"
            }
            children {
              internalType: "IntegerLiteralExpr"
              roles: Initialization
              roles: Declaration
              startPosition {
                line: 69
                col: 21
              }
              endPosition {
                line: 69
                col: 21
              }
            }
          }
        }
        children {
          internalType: "BinaryExpr"
          roles: Condition
          startPosition {
            line: 69
            col: 24
          }
          endPosition {
            line: 69
            col: 61
          }
          children {
            internalType: "BinaryExpr"
            roles: Condition
            roles: Left
            startPosition {
              line: 69
              col: 24
            }
            endPosition {
              line: 69
              col: 39
            }
            children {
              internalType: "NameExpr"
              roles: Condition
              roles: Left
              startPosition {
                line: 69
                col: 24
              }
              endPosition {
                line: 69
                col: 24
              }
              children {
                internalType: "SimpleName"
                roles: Condition
                roles: Left
                startPosition {
                  line: 69
                  col: 24
                }
                endPosition {
                  line: 69
                  col: 24
                }
                token: "i"
              }
            }
            children {
              internalType: "MethodCallExpr"
              roles: Right
              roles: Condition
              roles: Left
              startPosition {
                line: 69
                col: 28
              }
              endPosition {
                line: 69
                col: 39
              }
              children {
                internalType: "NameExpr"
                roles: Callee
                roles: Right
                roles: Condition
                roles: Left
                startPosition {
                  line: 69
                  col: 28
                }
                endPosition {
                  line: 69
                  col: 32
                }
                children {
                  internalType: "SimpleName"
                  roles: Callee
                  roles: Right
                  roles: Condition
                  roles: Left
                  startPosition {
                    line: 69
                    col: 28
                  }
                  endPosition {
                    line: 69
                    col: 32
                  }
                  token: "words"
                }
              }
              children {
                internalType: "SimpleName"
                roles: Call
                roles: Right
                roles: Condition
                roles: Left
                startPosition {
                  line: 69
                  col: 34
                }
                endPosition {
                  line: 69
                  col: 37
                }
                token: "size"
              }
              token: "MethodCall:size"
            }
            token: "LESS"
          }
          children {
            internalType: "BinaryExpr"
            roles: Right
            roles: Condition
            startPosition {
              line: 69
              col: 44
            }
            endPosition {
              line: 69
              col: 61
            }
            children {
              internalType: "NameExpr"
              roles: Right
              roles: Condition
              roles: Left
              startPosition {
                line: 69
                col: 44
              }
              endPosition {
                line: 69
                col: 44
              }
              children {
                internalType: "SimpleName"
                roles: Right
                roles: Condition
                roles: Left
                startPosition {
                  line: 69
                  col: 44
                }
                endPosition {
                  line: 69
                  col: 44
                }
                token: "i"
              }
            }
            children {
              internalType: "NameExpr"
              roles: Right
              roles: Condition
              startPosition {
                line: 69
                col: 48
              }
              endPosition {
                line: 69
                col: 61
              }
              children {
                internalType: "SimpleName"
                roles: Right
                roles: Condition
                startPosition {
                  line: 69
                  col: 48
                }
                endPosition {
                  line: 69
                  col: 61
                }
                token: "numWordsToShow"
              }
            }
            token: "LESS"
          }
          token: "AND"
        }
        children {
          internalType: "UnaryExpr"
          roles: Update
          startPosition {
            line: 69
            col: 64
          }
          endPosition {
            line: 69
            col: 66
          }
          children {
            internalType: "NameExpr"
            roles: Identifier
            roles: Update
            startPosition {
              line: 69
              col: 64
            }
            endPosition {
              line: 69
              col: 64
            }
            children {
              internalType: "SimpleName"
              roles: Identifier
              roles: Update
              startPosition {
                line: 69
                col: 64
              }
              endPosition {
                line: 69
                col: 64
              }
              token: "i"
            }
          }
          token: "POSTFIX_INCREMENT"
        }
        children {
          internalType: "ExpressionStmt"
          startPosition {
            line: 70
            col: 13
          }
          endPosition {
            line: 70
            col: 45
          }
          children {
            internalType: "MethodCallExpr"
            startPosition {
              line: 70
              col: 13
            }
            endPosition {
              line: 70
              col: 44
            }
            children {
              internalType: "FieldAccessExpr"
              roles: Callee
              startPosition {
                line: 70
                col: 13
              }
              endPosition {
                line: 70
                col: 22
              }
              children {
                internalType: "NameExpr"
                roles: Callee
                roles: Scope
                startPosition {
                  line: 70
                  col: 13
                }
                endPosition {
                  line: 70
                  col: 18
                }
                children {
                  internalType: "SimpleName"
                  roles: Callee
                  roles: Scope
                  startPosition {
                    line: 70
                    col: 13
                  }
                  endPosition {
                    line: 70
                    col: 18
                  }
                  token: "System"
                }
              }
              children {
                internalType: "SimpleName"
                roles: Callee
                roles: Identifier
                startPosition {
                  line: 70
                  col: 20
                }
                endPosition {
                  line: 70
                  col: 22
                }
                token: "out"
              }
              token: "FieldAccess:out"
            }
            children {
              internalType: "SimpleName"
              roles: Call
              startPosition {
                line: 70
                col: 24
              }
              endPosition {
                line: 70
                col: 30
              }
              token: "println"
            }
            children {
              internalType: "MethodCallExpr"
              roles: Argument
              startPosition {
                line: 70
                col: 32
              }
              endPosition {
                line: 70
                col: 43
              }
              children {
                internalType: "NameExpr"
                roles: Argument
                roles: Callee
                startPosition {
                  line: 70
                  col: 32
                }
                endPosition {
                  line: 70
                  col: 36
                }
                children {
                  internalType: "SimpleName"
                  roles: Argument
                  roles: Callee
                  startPosition {
                    line: 70
                    col: 32
                  }
                  endPosition {
                    line: 70
                    col: 36
                  }
                  token: "words"
                }
              }
              children {
                internalType: "SimpleName"
                roles: Call
                roles: Argument
                startPosition {
                  line: 70
                  col: 38
                }
                endPosition {
                  line: 70
                  col: 40
                }
                token: "get"
              }
              children {
                internalType: "NameExpr"
                roles: Argument
                startPosition {
                  line: 70
                  col: 42
                }
                endPosition {
                  line: 70
                  col: 42
                }
                children {
                  internalType: "SimpleName"
                  roles: Argument
                  startPosition {
                    line: 70
                    col: 42
                  }
                  endPosition {
                    line: 70
                    col: 42
                  }
                  token: "i"
                }
              }
              token: "MethodCall:get"
            }
            token: "MethodCall:println"
          }
        }
      }
    }
  }
  children {
    internalType: "MethodDeclaration"
    startPosition {
      line: 74
      col: 5
    }
    endPosition {
      line: 78
      col: 5
    }
    children {
      internalType: "Modifier"
      startPosition {
        line: 74
        col: 5
      }
      endPosition {
        line: 78
        col: 5
      }
      token: "private"
    }
    children {
      internalType: "Modifier"
      startPosition {
        line: 74
        col: 5
      }
      endPosition {
        line: 78
        col: 5
      }
      token: "static"
    }
    children {
      internalType: "SimpleName"
      startPosition {
        line: 74
        col: 25
      }
      endPosition {
        line: 74
        col: 33
      }
      token: "showWords"
    }
    children {
      internalType: "Parameter"
      roles: Argument
      startPosition {
        line: 74
        col: 35
      }
      endPosition {
        line: 74
        col: 60
      }
      children {
        internalType: "ClassOrInterfaceType"
        roles: Type
        roles: Argument
        startPosition {
          line: 74
          col: 35
        }
        endPosition {
          line: 74
          col: 54
        }
        children {
          internalType: "SimpleName"
          roles: Type
          roles: Argument
          startPosition {
            line: 74
            col: 35
          }
          endPosition {
            line: 74
            col: 37
          }
          token: "Map"
        }
        children {
          internalType: "ClassOrInterfaceType"
          roles: Type
          roles: Argument
          startPosition {
            line: 74
            col: 39
          }
          endPosition {
            line: 74
            col: 44
          }
          children {
            internalType: "SimpleName"
            roles: Type
            roles: Argument
            startPosition {
              line: 74
              col: 39
            }
            endPosition {
              line: 74
              col: 44
            }
            token: "String"
          }
          token: "Type:String"
        }
        children {
          internalType: "ClassOrInterfaceType"
          roles: Type
          roles: Argument
          startPosition {
            line: 74
            col: 47
          }
          endPosition {
            line: 74
            col: 53
          }
          children {
            internalType: "SimpleName"
            roles: Type
            roles: Argument
            startPosition {
              line: 74
              col: 47
            }
            endPosition {
              line: 74
              col: 53
            }
            token: "Integer"
          }
          token: "Type:Integer"
        }
        token: "Type:Map"
      }
      children {
        internalType: "SimpleName"
        roles: Argument
        roles: Identifier
        startPosition {
          line: 74
          col: 56
        }
        endPosition {
          line: 74
          col: 60
        }
        token: "words"
      }
    }
    children {
      internalType: "Parameter"
      roles: Argument
      startPosition {
        line: 74
        col: 63
      }
      endPosition {
        line: 74
        col: 80
      }
      children {
        internalType: "PrimitiveType"
        roles: Argument
        startPosition {
          line: 74
          col: 63
        }
        endPosition {
          line: 74
          col: 65
        }
        token: "int"
      }
      children {
        internalType: "SimpleName"
        roles: Argument
        roles: Identifier
        startPosition {
          line: 74
          col: 67
        }
        endPosition {
          line: 74
          col: 80
        }
        token: "numWordsToShow"
      }
    }
    children {
      internalType: "VoidType"
      startPosition {
        line: 74
        col: 20
      }
      endPosition {
        line: 74
        col: 23
      }
      token: "void"
    }
    children {
      internalType: "BlockStmt"
      startPosition {
        line: 74
        col: 83
      }
      endPosition {
        line: 78
        col: 5
      }
    }
  }
  children {
    internalType: "MethodDeclaration"
    startPosition {
      line: 83
      col: 5
    }
    endPosition {
      line: 90
      col: 5
    }
    children {
      internalType: "Modifier"
      startPosition {
        line: 83
        col: 5
      }
      endPosition {
        line: 90
        col: 5
      }
      token: "private"
    }
    children {
      internalType: "Modifier"
      startPosition {
        line: 83
        col: 5
      }
      endPosition {
        line: 90
        col: 5
      }
      token: "static"
    }
    children {
      internalType: "SimpleName"
      startPosition {
        line: 83
        col: 25
      }
      endPosition {
        line: 83
        col: 34
      }
      token: "performExp"
    }
    children {
      internalType: "VoidType"
      startPosition {
        line: 83
        col: 20
      }
      endPosition {
        line: 83
        col: 23
      }
      token: "void"
    }
    children {
      internalType: "BlockStmt"
      startPosition {
        line: 83
        col: 38
      }
      endPosition {
        line: 90
        col: 5
      }
      children {
        internalType: "ExpressionStmt"
        startPosition {
          line: 84
          col: 9
        }
        endPosition {
          line: 84
          col: 100
        }
        children {
          internalType: "VariableDeclarationExpr"
          startPosition {
            line: 84
            col: 9
          }
          endPosition {
            line: 84
            col: 99
          }
          children {
            internalType: "VariableDeclarator"
            roles: Declaration
            startPosition {
              line: 84
              col: 18
            }
            endPosition {
              line: 84
              col: 99
            }
            children {
              internalType: "ArrayType"
              roles: Type
              roles: Declaration
              startPosition {
                line: 84
                col: 9
              }
              endPosition {
                line: 84
                col: 16
              }
              children {
                internalType: "ClassOrInterfaceType"
                roles: Type
                roles: Declaration
                startPosition {
                  line: 84
                  col: 9
                }
                endPosition {
                  line: 84
                  col: 14
                }
                children {
                  internalType: "SimpleName"
                  roles: Type
                  roles: Declaration
                  startPosition {
                    line: 84
                    col: 9
                  }
                  endPosition {
                    line: 84
                    col: 14
                  }
                  token: "String"
                }
                token: "Type:String"
              }
            }
            children {
              internalType: "SimpleName"
              roles: Identifier
              roles: Declaration
              startPosition {
                line: 84
                col: 18
              }
              endPosition {
                line: 84
                col: 29
              }
              token: "smallerWorks"
            }
            children {
              internalType: "ArrayInitializerExpr"
              roles: Declaration
              startPosition {
                line: 84
                col: 33
              }
              endPosition {
                line: 84
                col: 99
              }
              children {
                internalType: "StringLiteralExpr"
                roles: Initialization
                roles: Declaration
                startPosition {
                  line: 84
                  col: 34
                }
                endPosition {
                  line: 84
                  col: 49
                }
                token: "smallWords.txt"
              }
              children {
                internalType: "StringLiteralExpr"
                roles: Initialization
                roles: Declaration
                startPosition {
                  line: 84
                  col: 52
                }
                endPosition {
                  line: 84
                  col: 63
                }
                token: "2BR02B.txt"
              }
              children {
                internalType: "StringLiteralExpr"
                roles: Initialization
                roles: Declaration
                startPosition {
                  line: 84
                  col: 66
                }
                endPosition {
                  line: 84
                  col: 76
                }
                token: "Alice.txt"
              }
              children {
                internalType: "StringLiteralExpr"
                roles: Initialization
                roles: Declaration
                startPosition {
                  line: 84
                  col: 79
                }
                endPosition {
                  line: 84
                  col: 98
                }
                token: "SherlockHolmes.txt"
              }
            }
          }
        }
      }
      children {
        internalType: "EmptyStmt"
        startPosition {
          line: 84
          col: 101
        }
        endPosition {
          line: 84
          col: 101
        }
      }
      children {
        internalType: "ExpressionStmt"
        startPosition {
          line: 85
          col: 9
        }
        endPosition {
          line: 85
          col: 51
        }
        children {
          internalType: "VariableDeclarationExpr"
          startPosition {
            line: 85
            col: 9
          }
          endPosition {
            line: 85
            col: 50
          }
          children {
            internalType: "VariableDeclarator"
            roles: Declaration
            startPosition {
              line: 85
              col: 18
            }
            endPosition {
              line: 85
              col: 50
            }
            children {
              internalType: "ArrayType"
              roles: Type
              roles: Declaration
              startPosition {
                line: 85
                col: 9
              }
              endPosition {
                line: 85
                col: 16
              }
              children {
                internalType: "ClassOrInterfaceType"
                roles: Type
                roles: Declaration
                startPosition {
                  line: 85
                  col: 9
                }
                endPosition {
                  line: 85
                  col: 14
                }
                children {
                  internalType: "SimpleName"
                  roles: Type
                  roles: Declaration
                  startPosition {
                    line: 85
                    col: 9
                  }
                  endPosition {
                    line: 85
                    col: 14
                  }
                  token: "String"
                }
                token: "Type:String"
              }
            }
            children {
              internalType: "SimpleName"
              roles: Identifier
              roles: Declaration
              startPosition {
                line: 85
                col: 18
              }
              endPosition {
                line: 85
                col: 24
              }
              token: "bigFile"
            }
            children {
              internalType: "ArrayInitializerExpr"
              roles: Declaration
              startPosition {
                line: 85
                col: 28
              }
              endPosition {
                line: 85
                col: 50
              }
              children {
                internalType: "StringLiteralExpr"
                roles: Initialization
                roles: Declaration
                startPosition {
                  line: 85
                  col: 29
                }
                endPosition {
                  line: 85
                  col: 49
                }
                token: "ciaFactBook2008.txt"
              }
            }
          }
        }
      }
      children {
        internalType: "ExpressionStmt"
        startPosition {
          line: 86
          col: 9
        }
        endPosition {
          line: 86
          col: 49
        }
        children {
          internalType: "MethodCallExpr"
          startPosition {
            line: 86
            col: 9
          }
          endPosition {
            line: 86
            col: 48
          }
          children {
            internalType: "SimpleName"
            roles: Call
            startPosition {
              line: 86
              col: 9
            }
            endPosition {
              line: 86
              col: 30
            }
            token: "timingExpWithArrayList"
          }
          children {
            internalType: "NameExpr"
            roles: Argument
            startPosition {
              line: 86
              col: 32
            }
            endPosition {
              line: 86
              col: 43
            }
            children {
              internalType: "SimpleName"
              roles: Argument
              startPosition {
                line: 86
                col: 32
              }
              endPosition {
                line: 86
                col: 43
              }
              token: "smallerWorks"
            }
          }
          children {
            internalType: "IntegerLiteralExpr"
            roles: Argument
            startPosition {
              line: 86
              col: 46
            }
            endPosition {
              line: 86
              col: 47
            }
          }
          token: "MethodCall:timingExpWithArrayList"
        }
      }
      children {
        internalType: "ExpressionStmt"
        startPosition {
          line: 87
          col: 9
        }
        endPosition {
          line: 87
          col: 43
        }
        children {
          internalType: "MethodCallExpr"
          startPosition {
            line: 87
            col: 9
          }
          endPosition {
            line: 87
            col: 42
          }
          children {
            internalType: "SimpleName"
            roles: Call
            startPosition {
              line: 87
              col: 9
            }
            endPosition {
              line: 87
              col: 30
            }
            token: "timingExpWithArrayList"
          }
          children {
            internalType: "NameExpr"
            roles: Argument
            startPosition {
              line: 87
              col: 32
            }
            endPosition {
              line: 87
              col: 38
            }
            children {
              internalType: "SimpleName"
              roles: Argument
              startPosition {
                line: 87
                col: 32
              }
              endPosition {
                line: 87
                col: 38
              }
              token: "bigFile"
            }
          }
          children {
            internalType: "IntegerLiteralExpr"
            roles: Argument
            startPosition {
              line: 87
              col: 41
            }
            endPosition {
              line: 87
              col: 41
            }
          }
          token: "MethodCall:timingExpWithArrayList"
        }
      }
      children {
        internalType: "ExpressionStmt"
        startPosition {
          line: 88
          col: 9
        }
        endPosition {
          line: 88
          col: 43
        }
        children {
          internalType: "MethodCallExpr"
          startPosition {
            line: 88
            col: 9
          }
          endPosition {
            line: 88
            col: 42
          }
          children {
            internalType: "SimpleName"
            roles: Call
            startPosition {
              line: 88
              col: 9
            }
            endPosition {
              line: 88
              col: 24
            }
            token: "timingExpWithMap"
          }
          children {
            internalType: "NameExpr"
            roles: Argument
            startPosition {
              line: 88
              col: 26
            }
            endPosition {
              line: 88
              col: 37
            }
            children {
              internalType: "SimpleName"
              roles: Argument
              startPosition {
                line: 88
                col: 26
              }
              endPosition {
                line: 88
                col: 37
              }
              token: "smallerWorks"
            }
          }
          children {
            internalType: "IntegerLiteralExpr"
            roles: Argument
            startPosition {
              line: 88
              col: 40
            }
            endPosition {
              line: 88
              col: 41
            }
          }
          token: "MethodCall:timingExpWithMap"
        }
      }
      children {
        internalType: "ExpressionStmt"
        startPosition {
          line: 89
          col: 9
        }
        endPosition {
          line: 89
          col: 37
        }
        children {
          internalType: "MethodCallExpr"
          startPosition {
            line: 89
            col: 9
          }
          endPosition {
            line: 89
            col: 36
          }
          children {
            internalType: "SimpleName"
            roles: Call
            startPosition {
              line: 89
              col: 9
            }
            endPosition {
              line: 89
              col: 24
            }
            token: "timingExpWithMap"
          }
          children {
            internalType: "NameExpr"
            roles: Argument
            startPosition {
              line: 89
              col: 26
            }
            endPosition {
              line: 89
              col: 32
            }
            children {
              internalType: "SimpleName"
              roles: Argument
              startPosition {
                line: 89
                col: 26
              }
              endPosition {
                line: 89
                col: 32
              }
              token: "bigFile"
            }
          }
          children {
            internalType: "IntegerLiteralExpr"
            roles: Argument
            startPosition {
              line: 89
              col: 35
            }
            endPosition {
              line: 89
              col: 35
            }
          }
          token: "MethodCall:timingExpWithMap"
        }
      }
    }
  }
  children {
    internalType: "MethodDeclaration"
    startPosition {
      line: 96
      col: 5
    }
    endPosition {
      line: 118
      col: 5
    }
    children {
      internalType: "Modifier"
      startPosition {
        line: 96
        col: 5
      }
      endPosition {
        line: 118
        col: 5
      }
      token: "private"
    }
    children {
      internalType: "Modifier"
      startPosition {
        line: 96
        col: 5
      }
      endPosition {
        line: 118
        col: 5
      }
      token: "static"
    }
    children {
      internalType: "SimpleName"
      startPosition {
        line: 96
        col: 25
      }
      endPosition {
        line: 96
        col: 40
      }
      token: "timingExpWithMap"
    }
    children {
      internalType: "Parameter"
      roles: Argument
      startPosition {
        line: 96
        col: 42
      }
      endPosition {
        line: 96
        col: 56
      }
      children {
        internalType: "ArrayType"
        roles: Argument
        startPosition {
          line: 96
          col: 42
        }
        endPosition {
          line: 96
          col: 49
        }
        children {
          internalType: "ClassOrInterfaceType"
          roles: Type
          roles: Argument
          startPosition {
            line: 96
            col: 42
          }
          endPosition {
            line: 96
            col: 47
          }
          children {
            internalType: "SimpleName"
            roles: Type
            roles: Argument
            startPosition {
              line: 96
              col: 42
            }
            endPosition {
              line: 96
              col: 47
            }
            token: "String"
          }
          token: "Type:String"
        }
      }
      children {
        internalType: "SimpleName"
        roles: Argument
        roles: Identifier
        startPosition {
          line: 96
          col: 51
        }
        endPosition {
          line: 96
          col: 56
        }
        token: "titles"
      }
    }
    children {
      internalType: "Parameter"
      roles: Argument
      startPosition {
        line: 96
        col: 59
      }
      endPosition {
        line: 96
        col: 68
      }
      children {
        internalType: "PrimitiveType"
        roles: Argument
        startPosition {
          line: 96
          col: 59
        }
        endPosition {
          line: 96
          col: 61
        }
        token: "int"
      }
      children {
        internalType: "SimpleName"
        roles: Argument
        roles: Identifier
        startPosition {
          line: 96
          col: 63
        }
        endPosition {
          line: 96
          col: 68
        }
        token: "numExp"
      }
    }
    children {
      internalType: "VoidType"
      startPosition {
        line: 96
        col: 20
      }
      endPosition {
        line: 96
        col: 23
      }
      token: "void"
    }
    children {
      internalType: "BlockStmt"
      startPosition {
        line: 96
        col: 71
      }
      endPosition {
        line: 118
        col: 5
      }
      children {
        internalType: "TryStmt"
        startPosition {
          line: 97
          col: 9
        }
        endPosition {
          line: 117
          col: 9
        }
        children {
          internalType: "BlockStmt"
          roles: Try
          startPosition {
            line: 97
            col: 13
          }
          endPosition {
            line: 114
            col: 9
          }
          children {
            internalType: "ExpressionStmt"
            roles: Try
            startPosition {
              line: 98
              col: 13
            }
            endPosition {
              line: 98
              col: 55
            }
            children {
              internalType: "VariableDeclarationExpr"
              roles: Try
              startPosition {
                line: 98
                col: 13
              }
              endPosition {
                line: 98
                col: 54
              }
              children {
                internalType: "VariableDeclarator"
                roles: Declaration
                roles: Try
                startPosition {
                  line: 98
                  col: 22
                }
                endPosition {
                  line: 98
                  col: 54
                }
                children {
                  internalType: "ArrayType"
                  roles: Type
                  roles: Declaration
                  roles: Try
                  startPosition {
                    line: 98
                    col: 13
                  }
                  endPosition {
                    line: 98
                    col: 20
                  }
                  children {
                    internalType: "PrimitiveType"
                    roles: Type
                    roles: Declaration
                    roles: Try
                    startPosition {
                      line: 98
                      col: 13
                    }
                    endPosition {
                      line: 98
                      col: 18
                    }
                    token: "double"
                  }
                }
                children {
                  internalType: "SimpleName"
                  roles: Identifier
                  roles: Declaration
                  roles: Try
                  startPosition {
                    line: 98
                    col: 22
                  }
                  endPosition {
                    line: 98
                    col: 26
                  }
                  token: "times"
                }
                children {
                  internalType: "ArrayCreationExpr"
                  roles: Declaration
                  roles: Try
                  startPosition {
                    line: 98
                    col: 30
                  }
                  endPosition {
                    line: 98
                    col: 54
                  }
                  children {
                    internalType: "PrimitiveType"
                    roles: Type
                    roles: Declaration
                    roles: Try
                    startPosition {
                      line: 98
                      col: 34
                    }
                    endPosition {
                      line: 98
                      col: 39
                    }
                    token: "double"
                  }
                  children {
                    internalType: "FieldAccessExpr"
                    roles: Declaration
                    roles: Try
                    startPosition {
                      line: 98
                      col: 41
                    }
                    endPosition {
                      line: 98
                      col: 53
                    }
                    children {
                      internalType: "NameExpr"
                      roles: Scope
                      roles: Declaration
                      roles: Try
                      startPosition {
                        line: 98
                        col: 41
                      }
                      endPosition {
                        line: 98
                        col: 46
                      }
                      children {
                        internalType: "SimpleName"
                        roles: Scope
                        roles: Declaration
                        roles: Try
                        startPosition {
                          line: 98
                          col: 41
                        }
                        endPosition {
                          line: 98
                          col: 46
                        }
                        token: "titles"
                      }
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Identifier
                      roles: Declaration
                      roles: Try
                      startPosition {
                        line: 98
                        col: 48
                      }
                      endPosition {
                        line: 98
                        col: 53
                      }
                      token: "length"
                    }
                    token: "FieldAccess:length"
                  }
                }
              }
            }
          }
          children {
            internalType: "ExpressionStmt"
            roles: Try
            startPosition {
              line: 99
              col: 13
            }
            endPosition {
              line: 99
              col: 35
            }
            children {
              internalType: "VariableDeclarationExpr"
              roles: Try
              startPosition {
                line: 99
                col: 13
              }
              endPosition {
                line: 99
                col: 34
              }
              children {
                internalType: "VariableDeclarator"
                roles: Declaration
                roles: Try
                startPosition {
                  line: 99
                  col: 23
                }
                endPosition {
                  line: 99
                  col: 34
                }
                children {
                  internalType: "PrimitiveType"
                  roles: Type
                  roles: Declaration
                  roles: Try
                  startPosition {
                    line: 99
                    col: 19
                  }
                  endPosition {
                    line: 99
                    col: 21
                  }
                  token: "int"
                }
                children {
                  internalType: "SimpleName"
                  roles: Identifier
                  roles: Declaration
                  roles: Try
                  startPosition {
                    line: 99
                    col: 23
                  }
                  endPosition {
                    line: 99
                    col: 29
                  }
                  token: "NUM_EXP"
                }
                children {
                  internalType: "IntegerLiteralExpr"
                  roles: Declaration
                  roles: Try
                  startPosition {
                    line: 99
                    col: 33
                  }
                  endPosition {
                    line: 99
                    col: 34
                  }
                }
              }
            }
          }
          children {
            internalType: "ForStmt"
            roles: Try
            startPosition {
              line: 100
              col: 13
            }
            endPosition {
              line: 111
              col: 13
            }
            children {
              internalType: "VariableDeclarationExpr"
              roles: Initialization
              roles: Try
              startPosition {
                line: 100
                col: 17
              }
              endPosition {
                line: 100
                col: 25
              }
              children {
                internalType: "VariableDeclarator"
                roles: Initialization
                roles: Declaration
                roles: Try
                startPosition {
                  line: 100
                  col: 21
                }
                endPosition {
                  line: 100
                  col: 25
                }
                children {
                  internalType: "PrimitiveType"
                  roles: Type
                  roles: Initialization
                  roles: Declaration
                  roles: Try
                  startPosition {
                    line: 100
                    col: 17
                  }
                  endPosition {
                    line: 100
                    col: 19
                  }
                  token: "int"
                }
                children {
                  internalType: "SimpleName"
                  roles: Initialization
                  roles: Identifier
                  roles: Declaration
                  roles: Try
                  startPosition {
                    line: 100
                    col: 21
                  }
                  endPosition {
                    line: 100
                    col: 21
                  }
                  token: "i"
                }
                children {
                  internalType: "IntegerLiteralExpr"
                  roles: Initialization
                  roles: Declaration
                  roles: Try
                  startPosition {
                    line: 100
                    col: 25
                  }
                  endPosition {
                    line: 100
                    col: 25
                  }
                }
              }
            }
            children {
              internalType: "BinaryExpr"
              roles: Condition
              roles: Try
              startPosition {
                line: 100
                col: 28
              }
              endPosition {
                line: 100
                col: 38
              }
              children {
                internalType: "NameExpr"
                roles: Condition
                roles: Try
                roles: Left
                startPosition {
                  line: 100
                  col: 28
                }
                endPosition {
                  line: 100
                  col: 28
                }
                children {
                  internalType: "SimpleName"
                  roles: Condition
                  roles: Try
                  roles: Left
                  startPosition {
                    line: 100
                    col: 28
                  }
                  endPosition {
                    line: 100
                    col: 28
                  }
                  token: "i"
                }
              }
              children {
                internalType: "NameExpr"
                roles: Right
                roles: Condition
                roles: Try
                startPosition {
                  line: 100
                  col: 32
                }
                endPosition {
                  line: 100
                  col: 38
                }
                children {
                  internalType: "SimpleName"
                  roles: Right
                  roles: Condition
                  roles: Try
                  startPosition {
                    line: 100
                    col: 32
                  }
                  endPosition {
                    line: 100
                    col: 38
                  }
                  token: "NUM_EXP"
                }
              }
              token: "LESS"
            }
            children {
              internalType: "UnaryExpr"
              roles: Try
              roles: Update
              startPosition {
                line: 100
                col: 41
              }
              endPosition {
                line: 100
                col: 43
              }
              children {
                internalType: "NameExpr"
                roles: Identifier
                roles: Try
                roles: Update
                startPosition {
                  line: 100
                  col: 41
                }
                endPosition {
                  line: 100
                  col: 41
                }
                children {
                  internalType: "SimpleName"
                  roles: Identifier
                  roles: Try
                  roles: Update
                  startPosition {
                    line: 100
                    col: 41
                  }
                  endPosition {
                    line: 100
                    col: 41
                  }
                  token: "i"
                }
              }
              token: "POSTFIX_INCREMENT"
            }
            children {
              internalType: "BlockStmt"
              roles: Try
              startPosition {
                line: 100
                col: 46
              }
              endPosition {
                line: 111
                col: 13
              }
              children {
                internalType: "ForStmt"
                roles: Try
                startPosition {
                  line: 101
                  col: 17
                }
                endPosition {
                  line: 110
                  col: 17
                }
                children {
                  internalType: "VariableDeclarationExpr"
                  roles: Initialization
                  roles: Try
                  startPosition {
                    line: 101
                    col: 21
                  }
                  endPosition {
                    line: 101
                    col: 29
                  }
                  children {
                    internalType: "VariableDeclarator"
                    roles: Initialization
                    roles: Declaration
                    roles: Try
                    startPosition {
                      line: 101
                      col: 25
                    }
                    endPosition {
                      line: 101
                      col: 29
                    }
                    children {
                      internalType: "PrimitiveType"
                      roles: Type
                      roles: Initialization
                      roles: Declaration
                      roles: Try
                      startPosition {
                        line: 101
                        col: 21
                      }
                      endPosition {
                        line: 101
                        col: 23
                      }
                      token: "int"
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Initialization
                      roles: Identifier
                      roles: Declaration
                      roles: Try
                      startPosition {
                        line: 101
                        col: 25
                      }
                      endPosition {
                        line: 101
                        col: 25
                      }
                      token: "j"
                    }
                    children {
                      internalType: "IntegerLiteralExpr"
                      roles: Initialization
                      roles: Declaration
                      roles: Try
                      startPosition {
                        line: 101
                        col: 29
                      }
                      endPosition {
                        line: 101
                        col: 29
                      }
                    }
                  }
                }
                children {
                  internalType: "BinaryExpr"
                  roles: Condition
                  roles: Try
                  startPosition {
                    line: 101
                    col: 32
                  }
                  endPosition {
                    line: 101
                    col: 48
                  }
                  children {
                    internalType: "NameExpr"
                    roles: Condition
                    roles: Try
                    roles: Left
                    startPosition {
                      line: 101
                      col: 32
                    }
                    endPosition {
                      line: 101
                      col: 32
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Condition
                      roles: Try
                      roles: Left
                      startPosition {
                        line: 101
                        col: 32
                      }
                      endPosition {
                        line: 101
                        col: 32
                      }
                      token: "j"
                    }
                  }
                  children {
                    internalType: "FieldAccessExpr"
                    roles: Right
                    roles: Condition
                    roles: Try
                    startPosition {
                      line: 101
                      col: 36
                    }
                    endPosition {
                      line: 101
                      col: 48
                    }
                    children {
                      internalType: "NameExpr"
                      roles: Scope
                      roles: Right
                      roles: Condition
                      roles: Try
                      startPosition {
                        line: 101
                        col: 36
                      }
                      endPosition {
                        line: 101
                        col: 41
                      }
                      children {
                        internalType: "SimpleName"
                        roles: Scope
                        roles: Right
                        roles: Condition
                        roles: Try
                        startPosition {
                          line: 101
                          col: 36
                        }
                        endPosition {
                          line: 101
                          col: 41
                        }
                        token: "titles"
                      }
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Right
                      roles: Condition
                      roles: Identifier
                      roles: Try
                      startPosition {
                        line: 101
                        col: 43
                      }
                      endPosition {
                        line: 101
                        col: 48
                      }
                      token: "length"
                    }
                    token: "FieldAccess:length"
                  }
                  token: "LESS"
                }
                children {
                  internalType: "UnaryExpr"
                  roles: Try
                  roles: Update
                  startPosition {
                    line: 101
                    col: 51
                  }
                  endPosition {
                    line: 101
                    col: 53
                  }
                  children {
                    internalType: "NameExpr"
                    roles: Identifier
                    roles: Try
                    roles: Update
                    startPosition {
                      line: 101
                      col: 51
                    }
                    endPosition {
                      line: 101
                      col: 51
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Identifier
                      roles: Try
                      roles: Update
                      startPosition {
                        line: 101
                        col: 51
                      }
                      endPosition {
                        line: 101
                        col: 51
                      }
                      token: "j"
                    }
                  }
                  token: "POSTFIX_INCREMENT"
                }
                children {
                  internalType: "BlockStmt"
                  roles: Try
                  startPosition {
                    line: 101
                    col: 56
                  }
                  endPosition {
                    line: 110
                    col: 17
                  }
                  children {
                    internalType: "ExpressionStmt"
                    roles: Try
                    startPosition {
                      line: 102
                      col: 21
                    }
                    endPosition {
                      line: 102
                      col: 75
                    }
                    children {
                      internalType: "VariableDeclarationExpr"
                      roles: Try
                      startPosition {
                        line: 102
                        col: 21
                      }
                      endPosition {
                        line: 102
                        col: 74
                      }
                      children {
                        internalType: "VariableDeclarator"
                        roles: Declaration
                        roles: Try
                        startPosition {
                          line: 102
                          col: 29
                        }
                        endPosition {
                          line: 102
                          col: 74
                        }
                        children {
                          internalType: "ClassOrInterfaceType"
                          roles: Type
                          roles: Declaration
                          roles: Try
                          startPosition {
                            line: 102
                            col: 21
                          }
                          endPosition {
                            line: 102
                            col: 27
                          }
                          children {
                            internalType: "SimpleName"
                            roles: Type
                            roles: Declaration
                            roles: Try
                            startPosition {
                              line: 102
                              col: 21
                            }
                            endPosition {
                              line: 102
                              col: 27
                            }
                            token: "Scanner"
                          }
                          token: "Type:Scanner"
                        }
                        children {
                          internalType: "SimpleName"
                          roles: Identifier
                          roles: Declaration
                          roles: Try
                          startPosition {
                            line: 102
                            col: 29
                          }
                          endPosition {
                            line: 102
                            col: 39
                          }
                          token: "fileScanner"
                        }
                        children {
                          internalType: "ObjectCreationExpr"
                          roles: Declaration
                          roles: Try
                          startPosition {
                            line: 102
                            col: 43
                          }
                          endPosition {
                            line: 102
                            col: 74
                          }
                          children {
                            internalType: "ClassOrInterfaceType"
                            roles: Type
                            roles: Declaration
                            roles: Try
                            startPosition {
                              line: 102
                              col: 47
                            }
                            endPosition {
                              line: 102
                              col: 53
                            }
                            children {
                              internalType: "SimpleName"
                              roles: Type
                              roles: Declaration
                              roles: Try
                              startPosition {
                                line: 102
                                col: 47
                              }
                              endPosition {
                                line: 102
                                col: 53
                              }
                              token: "Scanner"
                            }
                            token: "Type:Scanner"
                          }
                          children {
                            internalType: "ObjectCreationExpr"
                            roles: Argument
                            roles: Declaration
                            roles: Try
                            startPosition {
                              line: 102
                              col: 55
                            }
                            endPosition {
                              line: 102
                              col: 73
                            }
                            children {
                              internalType: "ClassOrInterfaceType"
                              roles: Type
                              roles: Argument
                              roles: Declaration
                              roles: Try
                              startPosition {
                                line: 102
                                col: 59
                              }
                              endPosition {
                                line: 102
                                col: 62
                              }
                              children {
                                internalType: "SimpleName"
                                roles: Type
                                roles: Argument
                                roles: Declaration
                                roles: Try
                                startPosition {
                                  line: 102
                                  col: 59
                                }
                                endPosition {
                                  line: 102
                                  col: 62
                                }
                                token: "File"
                              }
                              token: "Type:File"
                            }
                            children {
                              internalType: "ArrayAccessExpr"
                              roles: Argument
                              roles: Declaration
                              roles: Try
                              startPosition {
                                line: 102
                                col: 64
                              }
                              endPosition {
                                line: 102
                                col: 72
                              }
                              children {
                                internalType: "NameExpr"
                                roles: Argument
                                roles: Identifier
                                roles: Declaration
                                roles: Try
                                startPosition {
                                  line: 102
                                  col: 64
                                }
                                endPosition {
                                  line: 102
                                  col: 69
                                }
                                children {
                                  internalType: "SimpleName"
                                  roles: Argument
                                  roles: Identifier
                                  roles: Declaration
                                  roles: Try
                                  startPosition {
                                    line: 102
                                    col: 64
                                  }
                                  endPosition {
                                    line: 102
                                    col: 69
                                  }
                                  token: "titles"
                                }
                              }
                              children {
                                internalType: "NameExpr"
                                roles: Literal
                                roles: Argument
                                roles: Declaration
                                roles: Try
                                startPosition {
                                  line: 102
                                  col: 71
                                }
                                endPosition {
                                  line: 102
                                  col: 71
                                }
                                children {
                                  internalType: "SimpleName"
                                  roles: Literal
                                  roles: Argument
                                  roles: Declaration
                                  roles: Try
                                  startPosition {
                                    line: 102
                                    col: 71
                                  }
                                  endPosition {
                                    line: 102
                                    col: 71
                                  }
                                  token: "j"
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                  children {
                    internalType: "ExpressionStmt"
                    roles: Try
                    startPosition {
                      line: 103
                      col: 21
                    }
                    endPosition {
                      line: 103
                      col: 51
                    }
                    children {
                      internalType: "VariableDeclarationExpr"
                      roles: Try
                      startPosition {
                        line: 103
                        col: 21
                      }
                      endPosition {
                        line: 103
                        col: 50
                      }
                      children {
                        internalType: "VariableDeclarator"
                        roles: Declaration
                        roles: Try
                        startPosition {
                          line: 103
                          col: 31
                        }
                        endPosition {
                          line: 103
                          col: 50
                        }
                        children {
                          internalType: "ClassOrInterfaceType"
                          roles: Type
                          roles: Declaration
                          roles: Try
                          startPosition {
                            line: 103
                            col: 21
                          }
                          endPosition {
                            line: 103
                            col: 29
                          }
                          children {
                            internalType: "SimpleName"
                            roles: Type
                            roles: Declaration
                            roles: Try
                            startPosition {
                              line: 103
                              col: 21
                            }
                            endPosition {
                              line: 103
                              col: 29
                            }
                            token: "Stopwatch"
                          }
                          token: "Type:Stopwatch"
                        }
                        children {
                          internalType: "SimpleName"
                          roles: Identifier
                          roles: Declaration
                          roles: Try
                          startPosition {
                            line: 103
                            col: 31
                          }
                          endPosition {
                            line: 103
                            col: 32
                          }
                          token: "st"
                        }
                        children {
                          internalType: "ObjectCreationExpr"
                          roles: Declaration
                          roles: Try
                          startPosition {
                            line: 103
                            col: 36
                          }
                          endPosition {
                            line: 103
                            col: 50
                          }
                          children {
                            internalType: "ClassOrInterfaceType"
                            roles: Type
                            roles: Declaration
                            roles: Try
                            startPosition {
                              line: 103
                              col: 40
                            }
                            endPosition {
                              line: 103
                              col: 48
                            }
                            children {
                              internalType: "SimpleName"
                              roles: Type
                              roles: Declaration
                              roles: Try
                              startPosition {
                                line: 103
                                col: 40
                              }
                              endPosition {
                                line: 103
                                col: 48
                              }
                              token: "Stopwatch"
                            }
                            token: "Type:Stopwatch"
                          }
                        }
                      }
                    }
                  }
                  children {
                    internalType: "ExpressionStmt"
                    roles: Try
                    startPosition {
                      line: 104
                      col: 21
                    }
                    endPosition {
                      line: 104
                      col: 31
                    }
                    children {
                      internalType: "MethodCallExpr"
                      roles: Try
                      startPosition {
                        line: 104
                        col: 21
                      }
                      endPosition {
                        line: 104
                        col: 30
                      }
                      children {
                        internalType: "NameExpr"
                        roles: Callee
                        roles: Try
                        startPosition {
                          line: 104
                          col: 21
                        }
                        endPosition {
                          line: 104
                          col: 22
                        }
                        children {
                          internalType: "SimpleName"
                          roles: Callee
                          roles: Try
                          startPosition {
                            line: 104
                            col: 21
                          }
                          endPosition {
                            line: 104
                            col: 22
                          }
                          token: "st"
                        }
                      }
                      children {
                        internalType: "SimpleName"
                        roles: Call
                        roles: Try
                        startPosition {
                          line: 104
                          col: 24
                        }
                        endPosition {
                          line: 104
                          col: 28
                        }
                        token: "start"
                      }
                      token: "MethodCall:start"
                    }
                  }
                  children {
                    internalType: "ExpressionStmt"
                    roles: Try
                    startPosition {
                      line: 105
                      col: 21
                    }
                    endPosition {
                      line: 105
                      col: 80
                    }
                    children {
                      internalType: "VariableDeclarationExpr"
                      roles: Try
                      startPosition {
                        line: 105
                        col: 21
                      }
                      endPosition {
                        line: 105
                        col: 79
                      }
                      children {
                        internalType: "VariableDeclarator"
                        roles: Declaration
                        roles: Try
                        startPosition {
                          line: 105
                          col: 42
                        }
                        endPosition {
                          line: 105
                          col: 79
                        }
                        children {
                          internalType: "ClassOrInterfaceType"
                          roles: Type
                          roles: Declaration
                          roles: Try
                          startPosition {
                            line: 105
                            col: 21
                          }
                          endPosition {
                            line: 105
                            col: 40
                          }
                          children {
                            internalType: "SimpleName"
                            roles: Type
                            roles: Declaration
                            roles: Try
                            startPosition {
                              line: 105
                              col: 21
                            }
                            endPosition {
                              line: 105
                              col: 23
                            }
                            token: "Map"
                          }
                          children {
                            internalType: "ClassOrInterfaceType"
                            roles: Type
                            roles: Argument
                            roles: Declaration
                            roles: Try
                            startPosition {
                              line: 105
                              col: 25
                            }
                            endPosition {
                              line: 105
                              col: 30
                            }
                            children {
                              internalType: "SimpleName"
                              roles: Type
                              roles: Argument
                              roles: Declaration
                              roles: Try
                              startPosition {
                                line: 105
                                col: 25
                              }
                              endPosition {
                                line: 105
                                col: 30
                              }
                              token: "String"
                            }
                            token: "Type:String"
                          }
                          children {
                            internalType: "ClassOrInterfaceType"
                            roles: Type
                            roles: Argument
                            roles: Declaration
                            roles: Try
                            startPosition {
                              line: 105
                              col: 33
                            }
                            endPosition {
                              line: 105
                              col: 39
                            }
                            children {
                              internalType: "SimpleName"
                              roles: Type
                              roles: Argument
                              roles: Declaration
                              roles: Try
                              startPosition {
                                line: 105
                                col: 33
                              }
                              endPosition {
                                line: 105
                                col: 39
                              }
                              token: "Integer"
                            }
                            token: "Type:Integer"
                          }
                          token: "Type:Map"
                        }
                        children {
                          internalType: "SimpleName"
                          roles: Identifier
                          roles: Declaration
                          roles: Try
                          startPosition {
                            line: 105
                            col: 42
                          }
                          endPosition {
                            line: 105
                            col: 46
                          }
                          token: "words"
                        }
                        children {
                          internalType: "MethodCallExpr"
                          roles: Declaration
                          roles: Try
                          startPosition {
                            line: 105
                            col: 50
                          }
                          endPosition {
                            line: 105
                            col: 79
                          }
                          children {
                            internalType: "SimpleName"
                            roles: Call
                            roles: Declaration
                            roles: Try
                            startPosition {
                              line: 105
                              col: 50
                            }
                            endPosition {
                              line: 105
                              col: 66
                            }
                            token: "countWordsWithMap"
                          }
                          children {
                            internalType: "NameExpr"
                            roles: Argument
                            roles: Declaration
                            roles: Try
                            startPosition {
                              line: 105
                              col: 68
                            }
                            endPosition {
                              line: 105
                              col: 78
                            }
                            children {
                              internalType: "SimpleName"
                              roles: Argument
                              roles: Declaration
                              roles: Try
                              startPosition {
                                line: 105
                                col: 68
                              }
                              endPosition {
                                line: 105
                                col: 78
                              }
                              token: "fileScanner"
                            }
                          }
                          token: "MethodCall:countWordsWithMap"
                        }
                      }
                    }
                  }
                  children {
                    internalType: "ExpressionStmt"
                    roles: Try
                    startPosition {
                      line: 106
                      col: 21
                    }
                    endPosition {
                      line: 106
                      col: 30
                    }
                    children {
                      internalType: "MethodCallExpr"
                      roles: Try
                      startPosition {
                        line: 106
                        col: 21
                      }
                      endPosition {
                        line: 106
                        col: 29
                      }
                      children {
                        internalType: "NameExpr"
                        roles: Callee
                        roles: Try
                        startPosition {
                          line: 106
                          col: 21
                        }
                        endPosition {
                          line: 106
                          col: 22
                        }
                        children {
                          internalType: "SimpleName"
                          roles: Callee
                          roles: Try
                          startPosition {
                            line: 106
                            col: 21
                          }
                          endPosition {
                            line: 106
                            col: 22
                          }
                          token: "st"
                        }
                      }
                      children {
                        internalType: "SimpleName"
                        roles: Call
                        roles: Try
                        startPosition {
                          line: 106
                          col: 24
                        }
                        endPosition {
                          line: 106
                          col: 27
                        }
                        token: "stop"
                      }
                      token: "MethodCall:stop"
                    }
                  }
                  children {
                    internalType: "ExpressionStmt"
                    roles: Try
                    startPosition {
                      line: 107
                      col: 21
                    }
                    endPosition {
                      line: 107
                      col: 53
                    }
                    children {
                      internalType: "MethodCallExpr"
                      roles: Try
                      startPosition {
                        line: 107
                        col: 21
                      }
                      endPosition {
                        line: 107
                        col: 52
                      }
                      children {
                        internalType: "FieldAccessExpr"
                        roles: Callee
                        roles: Try
                        startPosition {
                          line: 107
                          col: 21
                        }
                        endPosition {
                          line: 107
                          col: 30
                        }
                        children {
                          internalType: "NameExpr"
                          roles: Callee
                          roles: Scope
                          roles: Try
                          startPosition {
                            line: 107
                            col: 21
                          }
                          endPosition {
                            line: 107
                            col: 26
                          }
                          children {
                            internalType: "SimpleName"
                            roles: Callee
                            roles: Scope
                            roles: Try
                            startPosition {
                              line: 107
                              col: 21
                            }
                            endPosition {
                              line: 107
                              col: 26
                            }
                            token: "System"
                          }
                        }
                        children {
                          internalType: "SimpleName"
                          roles: Callee
                          roles: Identifier
                          roles: Try
                          startPosition {
                            line: 107
                            col: 28
                          }
                          endPosition {
                            line: 107
                            col: 30
                          }
                          token: "out"
                        }
                        token: "FieldAccess:out"
                      }
                      children {
                        internalType: "SimpleName"
                        roles: Call
                        roles: Try
                        startPosition {
                          line: 107
                          col: 32
                        }
                        endPosition {
                          line: 107
                          col: 38
                        }
                        token: "println"
                      }
                      children {
                        internalType: "MethodCallExpr"
                        roles: Argument
                        roles: Try
                        startPosition {
                          line: 107
                          col: 40
                        }
                        endPosition {
                          line: 107
                          col: 51
                        }
                        children {
                          internalType: "NameExpr"
                          roles: Argument
                          roles: Callee
                          roles: Try
                          startPosition {
                            line: 107
                            col: 40
                          }
                          endPosition {
                            line: 107
                            col: 44
                          }
                          children {
                            internalType: "SimpleName"
                            roles: Argument
                            roles: Callee
                            roles: Try
                            startPosition {
                              line: 107
                              col: 40
                            }
                            endPosition {
                              line: 107
                              col: 44
                            }
                            token: "words"
                          }
                        }
                        children {
                          internalType: "SimpleName"
                          roles: Call
                          roles: Argument
                          roles: Try
                          startPosition {
                            line: 107
                            col: 46
                          }
                          endPosition {
                            line: 107
                            col: 49
                          }
                          token: "size"
                        }
                        token: "MethodCall:size"
                      }
                      token: "MethodCall:println"
                    }
                  }
                  children {
                    internalType: "ExpressionStmt"
                    roles: Try
                    startPosition {
                      line: 108
                      col: 21
                    }
                    endPosition {
                      line: 108
                      col: 42
                    }
                    children {
                      internalType: "AssignExpr"
                      roles: Try
                      startPosition {
                        line: 108
                        col: 21
                      }
                      endPosition {
                        line: 108
                        col: 41
                      }
                      children {
                        internalType: "ArrayAccessExpr"
                        roles: Try
                        roles: Left
                        startPosition {
                          line: 108
                          col: 21
                        }
                        endPosition {
                          line: 108
                          col: 28
                        }
                        children {
                          internalType: "NameExpr"
                          roles: Identifier
                          roles: Try
                          roles: Left
                          startPosition {
                            line: 108
                            col: 21
                          }
                          endPosition {
                            line: 108
                            col: 25
                          }
                          children {
                            internalType: "SimpleName"
                            roles: Identifier
                            roles: Try
                            roles: Left
                            startPosition {
                              line: 108
                              col: 21
                            }
                            endPosition {
                              line: 108
                              col: 25
                            }
                            token: "times"
                          }
                        }
                        children {
                          internalType: "NameExpr"
                          roles: Literal
                          roles: Try
                          roles: Left
                          startPosition {
                            line: 108
                            col: 27
                          }
                          endPosition {
                            line: 108
                            col: 27
                          }
                          children {
                            internalType: "SimpleName"
                            roles: Literal
                            roles: Try
                            roles: Left
                            startPosition {
                              line: 108
                              col: 27
                            }
                            endPosition {
                              line: 108
                              col: 27
                            }
                            token: "j"
                          }
                        }
                      }
                      children {
                        internalType: "MethodCallExpr"
                        roles: Right
                        roles: Try
                        startPosition {
                          line: 108
                          col: 33
                        }
                        endPosition {
                          line: 108
                          col: 41
                        }
                        children {
                          internalType: "NameExpr"
                          roles: Callee
                          roles: Right
                          roles: Try
                          startPosition {
                            line: 108
                            col: 33
                          }
                          endPosition {
                            line: 108
                            col: 34
                          }
                          children {
                            internalType: "SimpleName"
                            roles: Callee
                            roles: Right
                            roles: Try
                            startPosition {
                              line: 108
                              col: 33
                            }
                            endPosition {
                              line: 108
                              col: 34
                            }
                            token: "st"
                          }
                        }
                        children {
                          internalType: "SimpleName"
                          roles: Call
                          roles: Right
                          roles: Try
                          startPosition {
                            line: 108
                            col: 36
                          }
                          endPosition {
                            line: 108
                            col: 39
                          }
                          token: "time"
                        }
                        token: "MethodCall:time"
                      }
                      token: "PLUS"
                    }
                  }
                  children {
                    internalType: "ExpressionStmt"
                    roles: Try
                    startPosition {
                      line: 109
                      col: 21
                    }
                    endPosition {
                      line: 109
                      col: 40
                    }
                    children {
                      internalType: "MethodCallExpr"
                      roles: Try
                      startPosition {
                        line: 109
                        col: 21
                      }
                      endPosition {
                        line: 109
                        col: 39
                      }
                      children {
                        internalType: "NameExpr"
                        roles: Callee
                        roles: Try
                        startPosition {
                          line: 109
                          col: 21
                        }
                        endPosition {
                          line: 109
                          col: 31
                        }
                        children {
                          internalType: "SimpleName"
                          roles: Callee
                          roles: Try
                          startPosition {
                            line: 109
                            col: 21
                          }
                          endPosition {
                            line: 109
                            col: 31
                          }
                          token: "fileScanner"
                        }
                      }
                      children {
                        internalType: "SimpleName"
                        roles: Call
                        roles: Try
                        startPosition {
                          line: 109
                          col: 33
                        }
                        endPosition {
                          line: 109
                          col: 37
                        }
                        token: "close"
                      }
                      token: "MethodCall:close"
                    }
                  }
                }
              }
            }
          }
          children {
            internalType: "ForEachStmt"
            roles: Try
            startPosition {
              line: 112
              col: 13
            }
            endPosition {
              line: 113
              col: 48
            }
            children {
              internalType: "VariableDeclarationExpr"
              roles: Try
              roles: Variable
              startPosition {
                line: 112
                col: 17
              }
              endPosition {
                line: 112
                col: 24
              }
              children {
                internalType: "VariableDeclarator"
                roles: Declaration
                roles: Try
                roles: Variable
                startPosition {
                  line: 112
                  col: 24
                }
                endPosition {
                  line: 112
                  col: 24
                }
                children {
                  internalType: "PrimitiveType"
                  roles: Type
                  roles: Declaration
                  roles: Try
                  roles: Variable
                  startPosition {
                    line: 112
                    col: 17
                  }
                  endPosition {
                    line: 112
                    col: 22
                  }
                  token: "double"
                }
                children {
                  internalType: "SimpleName"
                  roles: Identifier
                  roles: Declaration
                  roles: Try
                  roles: Variable
                  startPosition {
                    line: 112
                    col: 24
                  }
                  endPosition {
                    line: 112
                    col: 24
                  }
                  token: "a"
                }
              }
            }
            children {
              internalType: "NameExpr"
              roles: Expression
              roles: Try
              startPosition {
                line: 112
                col: 28
              }
              endPosition {
                line: 112
                col: 32
              }
              children {
                internalType: "SimpleName"
                roles: Expression
                roles: Try
                startPosition {
                  line: 112
                  col: 28
                }
                endPosition {
                  line: 112
                  col: 32
                }
                token: "times"
              }
            }
            children {
              internalType: "ExpressionStmt"
              roles: Try
              startPosition {
                line: 113
                col: 17
              }
              endPosition {
                line: 113
                col: 48
              }
              children {
                internalType: "MethodCallExpr"
                roles: Try
                startPosition {
                  line: 113
                  col: 17
                }
                endPosition {
                  line: 113
                  col: 47
                }
                children {
                  internalType: "FieldAccessExpr"
                  roles: Callee
                  roles: Try
                  startPosition {
                    line: 113
                    col: 17
                  }
                  endPosition {
                    line: 113
                    col: 26
                  }
                  children {
                    internalType: "NameExpr"
                    roles: Callee
                    roles: Scope
                    roles: Try
                    startPosition {
                      line: 113
                      col: 17
                    }
                    endPosition {
                      line: 113
                      col: 22
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Callee
                      roles: Scope
                      roles: Try
                      startPosition {
                        line: 113
                        col: 17
                      }
                      endPosition {
                        line: 113
                        col: 22
                      }
                      token: "System"
                    }
                  }
                  children {
                    internalType: "SimpleName"
                    roles: Callee
                    roles: Identifier
                    roles: Try
                    startPosition {
                      line: 113
                      col: 24
                    }
                    endPosition {
                      line: 113
                      col: 26
                    }
                    token: "out"
                  }
                  token: "FieldAccess:out"
                }
                children {
                  internalType: "SimpleName"
                  roles: Call
                  roles: Try
                  startPosition {
                    line: 113
                    col: 28
                  }
                  endPosition {
                    line: 113
                    col: 34
                  }
                  token: "println"
                }
                children {
                  internalType: "BinaryExpr"
                  roles: Argument
                  roles: Try
                  startPosition {
                    line: 113
                    col: 36
                  }
                  endPosition {
                    line: 113
                    col: 46
                  }
                  children {
                    internalType: "NameExpr"
                    roles: Argument
                    roles: Try
                    roles: Left
                    startPosition {
                      line: 113
                      col: 36
                    }
                    endPosition {
                      line: 113
                      col: 36
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Argument
                      roles: Try
                      roles: Left
                      startPosition {
                        line: 113
                        col: 36
                      }
                      endPosition {
                        line: 113
                        col: 36
                      }
                      token: "a"
                    }
                  }
                  children {
                    internalType: "NameExpr"
                    roles: Argument
                    roles: Right
                    roles: Try
                    startPosition {
                      line: 113
                      col: 40
                    }
                    endPosition {
                      line: 113
                      col: 46
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Argument
                      roles: Right
                      roles: Try
                      startPosition {
                        line: 113
                        col: 40
                      }
                      endPosition {
                        line: 113
                        col: 46
                      }
                      token: "NUM_EXP"
                    }
                  }
                  token: "DIVIDE"
                }
                token: "MethodCall:println"
              }
            }
          }
        }
        children {
          internalType: "CatchClause"
          startPosition {
            line: 115
            col: 9
          }
          endPosition {
            line: 117
            col: 9
          }
          children {
            internalType: "Parameter"
            roles: Argument
            startPosition {
              line: 115
              col: 15
            }
            endPosition {
              line: 115
              col: 37
            }
            children {
              internalType: "ClassOrInterfaceType"
              roles: Type
              roles: Argument
              startPosition {
                line: 115
                col: 15
              }
              endPosition {
                line: 115
                col: 35
              }
              children {
                internalType: "SimpleName"
                roles: Type
                roles: Argument
                startPosition {
                  line: 115
                  col: 15
                }
                endPosition {
                  line: 115
                  col: 35
                }
                token: "FileNotFoundException"
              }
              token: "Type:FileNotFoundException"
            }
            children {
              internalType: "SimpleName"
              roles: Argument
              roles: Identifier
              startPosition {
                line: 115
                col: 37
              }
              endPosition {
                line: 115
                col: 37
              }
              token: "e"
            }
          }
          children {
            internalType: "BlockStmt"
            roles: Catch
            startPosition {
              line: 115
              col: 40
            }
            endPosition {
              line: 117
              col: 9
            }
            children {
              internalType: "ExpressionStmt"
              roles: Catch
              startPosition {
                line: 116
                col: 13
              }
              endPosition {
                line: 116
                col: 90
              }
              children {
                internalType: "MethodCallExpr"
                roles: Catch
                startPosition {
                  line: 116
                  col: 13
                }
                endPosition {
                  line: 116
                  col: 89
                }
                children {
                  internalType: "FieldAccessExpr"
                  roles: Callee
                  roles: Catch
                  startPosition {
                    line: 116
                    col: 13
                  }
                  endPosition {
                    line: 116
                    col: 22
                  }
                  children {
                    internalType: "NameExpr"
                    roles: Callee
                    roles: Scope
                    roles: Catch
                    startPosition {
                      line: 116
                      col: 13
                    }
                    endPosition {
                      line: 116
                      col: 18
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Callee
                      roles: Scope
                      roles: Catch
                      startPosition {
                        line: 116
                        col: 13
                      }
                      endPosition {
                        line: 116
                        col: 18
                      }
                      token: "System"
                    }
                  }
                  children {
                    internalType: "SimpleName"
                    roles: Callee
                    roles: Identifier
                    roles: Catch
                    startPosition {
                      line: 116
                      col: 20
                    }
                    endPosition {
                      line: 116
                      col: 22
                    }
                    token: "out"
                  }
                  token: "FieldAccess:out"
                }
                children {
                  internalType: "SimpleName"
                  roles: Call
                  roles: Catch
                  startPosition {
                    line: 116
                    col: 24
                  }
                  endPosition {
                    line: 116
                    col: 30
                  }
                  token: "println"
                }
                children {
                  internalType: "BinaryExpr"
                  roles: Argument
                  roles: Catch
                  startPosition {
                    line: 116
                    col: 32
                  }
                  endPosition {
                    line: 116
                    col: 88
                  }
                  children {
                    internalType: "StringLiteralExpr"
                    roles: Argument
                    roles: Catch
                    roles: Left
                    startPosition {
                      line: 116
                      col: 32
                    }
                    endPosition {
                      line: 116
                      col: 84
                    }
                    token: "Problem reading the data file. Exiting the program."
                  }
                  children {
                    internalType: "NameExpr"
                    roles: Argument
                    roles: Right
                    roles: Catch
                    startPosition {
                      line: 116
                      col: 88
                    }
                    endPosition {
                      line: 116
                      col: 88
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Argument
                      roles: Right
                      roles: Catch
                      startPosition {
                        line: 116
                        col: 88
                      }
                      endPosition {
                        line: 116
                        col: 88
                      }
                      token: "e"
                    }
                  }
                  token: "PLUS"
                }
                token: "MethodCall:println"
              }
            }
          }
        }
      }
    }
  }
  children {
    internalType: "MethodDeclaration"
    startPosition {
      line: 124
      col: 5
    }
    endPosition {
      line: 144
      col: 5
    }
    children {
      internalType: "Modifier"
      startPosition {
        line: 124
        col: 5
      }
      endPosition {
        line: 144
        col: 5
      }
      token: "private"
    }
    children {
      internalType: "Modifier"
      startPosition {
        line: 124
        col: 5
      }
      endPosition {
        line: 144
        col: 5
      }
      token: "static"
    }
    children {
      internalType: "SimpleName"
      startPosition {
        line: 124
        col: 25
      }
      endPosition {
        line: 124
        col: 46
      }
      token: "timingExpWithArrayList"
    }
    children {
      internalType: "Parameter"
      roles: Argument
      startPosition {
        line: 124
        col: 48
      }
      endPosition {
        line: 124
        col: 62
      }
      children {
        internalType: "ArrayType"
        roles: Argument
        startPosition {
          line: 124
          col: 48
        }
        endPosition {
          line: 124
          col: 55
        }
        children {
          internalType: "ClassOrInterfaceType"
          roles: Type
          roles: Argument
          startPosition {
            line: 124
            col: 48
          }
          endPosition {
            line: 124
            col: 53
          }
          children {
            internalType: "SimpleName"
            roles: Type
            roles: Argument
            startPosition {
              line: 124
              col: 48
            }
            endPosition {
              line: 124
              col: 53
            }
            token: "String"
          }
          token: "Type:String"
        }
      }
      children {
        internalType: "SimpleName"
        roles: Argument
        roles: Identifier
        startPosition {
          line: 124
          col: 57
        }
        endPosition {
          line: 124
          col: 62
        }
        token: "titles"
      }
    }
    children {
      internalType: "Parameter"
      roles: Argument
      startPosition {
        line: 124
        col: 65
      }
      endPosition {
        line: 124
        col: 74
      }
      children {
        internalType: "PrimitiveType"
        roles: Argument
        startPosition {
          line: 124
          col: 65
        }
        endPosition {
          line: 124
          col: 67
        }
        token: "int"
      }
      children {
        internalType: "SimpleName"
        roles: Argument
        roles: Identifier
        startPosition {
          line: 124
          col: 69
        }
        endPosition {
          line: 124
          col: 74
        }
        token: "numExp"
      }
    }
    children {
      internalType: "VoidType"
      startPosition {
        line: 124
        col: 20
      }
      endPosition {
        line: 124
        col: 23
      }
      token: "void"
    }
    children {
      internalType: "BlockStmt"
      startPosition {
        line: 124
        col: 77
      }
      endPosition {
        line: 144
        col: 5
      }
      children {
        internalType: "TryStmt"
        startPosition {
          line: 125
          col: 9
        }
        endPosition {
          line: 143
          col: 9
        }
        children {
          internalType: "BlockStmt"
          roles: Try
          startPosition {
            line: 125
            col: 13
          }
          endPosition {
            line: 140
            col: 9
          }
          children {
            internalType: "ExpressionStmt"
            roles: Try
            startPosition {
              line: 126
              col: 13
            }
            endPosition {
              line: 126
              col: 55
            }
            children {
              internalType: "VariableDeclarationExpr"
              roles: Try
              startPosition {
                line: 126
                col: 13
              }
              endPosition {
                line: 126
                col: 54
              }
              children {
                internalType: "VariableDeclarator"
                roles: Declaration
                roles: Try
                startPosition {
                  line: 126
                  col: 22
                }
                endPosition {
                  line: 126
                  col: 54
                }
                children {
                  internalType: "ArrayType"
                  roles: Type
                  roles: Declaration
                  roles: Try
                  startPosition {
                    line: 126
                    col: 13
                  }
                  endPosition {
                    line: 126
                    col: 20
                  }
                  children {
                    internalType: "PrimitiveType"
                    roles: Type
                    roles: Declaration
                    roles: Try
                    startPosition {
                      line: 126
                      col: 13
                    }
                    endPosition {
                      line: 126
                      col: 18
                    }
                    token: "double"
                  }
                }
                children {
                  internalType: "SimpleName"
                  roles: Identifier
                  roles: Declaration
                  roles: Try
                  startPosition {
                    line: 126
                    col: 22
                  }
                  endPosition {
                    line: 126
                    col: 26
                  }
                  token: "times"
                }
                children {
                  internalType: "ArrayCreationExpr"
                  roles: Declaration
                  roles: Try
                  startPosition {
                    line: 126
                    col: 30
                  }
                  endPosition {
                    line: 126
                    col: 54
                  }
                  children {
                    internalType: "PrimitiveType"
                    roles: Type
                    roles: Declaration
                    roles: Try
                    startPosition {
                      line: 126
                      col: 34
                    }
                    endPosition {
                      line: 126
                      col: 39
                    }
                    token: "double"
                  }
                  children {
                    internalType: "FieldAccessExpr"
                    roles: Declaration
                    roles: Try
                    startPosition {
                      line: 126
                      col: 41
                    }
                    endPosition {
                      line: 126
                      col: 53
                    }
                    children {
                      internalType: "NameExpr"
                      roles: Scope
                      roles: Declaration
                      roles: Try
                      startPosition {
                        line: 126
                        col: 41
                      }
                      endPosition {
                        line: 126
                        col: 46
                      }
                      children {
                        internalType: "SimpleName"
                        roles: Scope
                        roles: Declaration
                        roles: Try
                        startPosition {
                          line: 126
                          col: 41
                        }
                        endPosition {
                          line: 126
                          col: 46
                        }
                        token: "titles"
                      }
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Identifier
                      roles: Declaration
                      roles: Try
                      startPosition {
                        line: 126
                        col: 48
                      }
                      endPosition {
                        line: 126
                        col: 53
                      }
                      token: "length"
                    }
                    token: "FieldAccess:length"
                  }
                }
              }
            }
          }
          children {
            internalType: "ForStmt"
            roles: Try
            startPosition {
              line: 127
              col: 13
            }
            endPosition {
              line: 137
              col: 13
            }
            children {
              internalType: "VariableDeclarationExpr"
              roles: Initialization
              roles: Try
              startPosition {
                line: 127
                col: 17
              }
              endPosition {
                line: 127
                col: 25
              }
              children {
                internalType: "VariableDeclarator"
                roles: Initialization
                roles: Declaration
                roles: Try
                startPosition {
                  line: 127
                  col: 21
                }
                endPosition {
                  line: 127
                  col: 25
                }
                children {
                  internalType: "PrimitiveType"
                  roles: Type
                  roles: Initialization
                  roles: Declaration
                  roles: Try
                  startPosition {
                    line: 127
                    col: 17
                  }
                  endPosition {
                    line: 127
                    col: 19
                  }
                  token: "int"
                }
                children {
                  internalType: "SimpleName"
                  roles: Initialization
                  roles: Identifier
                  roles: Declaration
                  roles: Try
                  startPosition {
                    line: 127
                    col: 21
                  }
                  endPosition {
                    line: 127
                    col: 21
                  }
                  token: "i"
                }
                children {
                  internalType: "IntegerLiteralExpr"
                  roles: Initialization
                  roles: Declaration
                  roles: Try
                  startPosition {
                    line: 127
                    col: 25
                  }
                  endPosition {
                    line: 127
                    col: 25
                  }
                }
              }
            }
            children {
              internalType: "BinaryExpr"
              roles: Condition
              roles: Try
              startPosition {
                line: 127
                col: 28
              }
              endPosition {
                line: 127
                col: 37
              }
              children {
                internalType: "NameExpr"
                roles: Condition
                roles: Try
                roles: Left
                startPosition {
                  line: 127
                  col: 28
                }
                endPosition {
                  line: 127
                  col: 28
                }
                children {
                  internalType: "SimpleName"
                  roles: Condition
                  roles: Try
                  roles: Left
                  startPosition {
                    line: 127
                    col: 28
                  }
                  endPosition {
                    line: 127
                    col: 28
                  }
                  token: "i"
                }
              }
              children {
                internalType: "NameExpr"
                roles: Right
                roles: Condition
                roles: Try
                startPosition {
                  line: 127
                  col: 32
                }
                endPosition {
                  line: 127
                  col: 37
                }
                children {
                  internalType: "SimpleName"
                  roles: Right
                  roles: Condition
                  roles: Try
                  startPosition {
                    line: 127
                    col: 32
                  }
                  endPosition {
                    line: 127
                    col: 37
                  }
                  token: "numExp"
                }
              }
              token: "LESS"
            }
            children {
              internalType: "UnaryExpr"
              roles: Try
              roles: Update
              startPosition {
                line: 127
                col: 40
              }
              endPosition {
                line: 127
                col: 42
              }
              children {
                internalType: "NameExpr"
                roles: Identifier
                roles: Try
                roles: Update
                startPosition {
                  line: 127
                  col: 40
                }
                endPosition {
                  line: 127
                  col: 40
                }
                children {
                  internalType: "SimpleName"
                  roles: Identifier
                  roles: Try
                  roles: Update
                  startPosition {
                    line: 127
                    col: 40
                  }
                  endPosition {
                    line: 127
                    col: 40
                  }
                  token: "i"
                }
              }
              token: "POSTFIX_INCREMENT"
            }
            children {
              internalType: "BlockStmt"
              roles: Try
              startPosition {
                line: 127
                col: 45
              }
              endPosition {
                line: 137
                col: 13
              }
              children {
                internalType: "ForStmt"
                roles: Try
                startPosition {
                  line: 128
                  col: 17
                }
                endPosition {
                  line: 136
                  col: 17
                }
                children {
                  internalType: "VariableDeclarationExpr"
                  roles: Initialization
                  roles: Try
                  startPosition {
                    line: 128
                    col: 21
                  }
                  endPosition {
                    line: 128
                    col: 29
                  }
                  children {
                    internalType: "VariableDeclarator"
                    roles: Initialization
                    roles: Declaration
                    roles: Try
                    startPosition {
                      line: 128
                      col: 25
                    }
                    endPosition {
                      line: 128
                      col: 29
                    }
                    children {
                      internalType: "PrimitiveType"
                      roles: Type
                      roles: Initialization
                      roles: Declaration
                      roles: Try
                      startPosition {
                        line: 128
                        col: 21
                      }
                      endPosition {
                        line: 128
                        col: 23
                      }
                      token: "int"
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Initialization
                      roles: Identifier
                      roles: Declaration
                      roles: Try
                      startPosition {
                        line: 128
                        col: 25
                      }
                      endPosition {
                        line: 128
                        col: 25
                      }
                      token: "j"
                    }
                    children {
                      internalType: "IntegerLiteralExpr"
                      roles: Initialization
                      roles: Declaration
                      roles: Try
                      startPosition {
                        line: 128
                        col: 29
                      }
                      endPosition {
                        line: 128
                        col: 29
                      }
                    }
                  }
                }
                children {
                  internalType: "BinaryExpr"
                  roles: Condition
                  roles: Try
                  startPosition {
                    line: 128
                    col: 32
                  }
                  endPosition {
                    line: 128
                    col: 48
                  }
                  children {
                    internalType: "NameExpr"
                    roles: Condition
                    roles: Try
                    roles: Left
                    startPosition {
                      line: 128
                      col: 32
                    }
                    endPosition {
                      line: 128
                      col: 32
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Condition
                      roles: Try
                      roles: Left
                      startPosition {
                        line: 128
                        col: 32
                      }
                      endPosition {
                        line: 128
                        col: 32
                      }
                      token: "j"
                    }
                  }
                  children {
                    internalType: "FieldAccessExpr"
                    roles: Right
                    roles: Condition
                    roles: Try
                    startPosition {
                      line: 128
                      col: 36
                    }
                    endPosition {
                      line: 128
                      col: 48
                    }
                    children {
                      internalType: "NameExpr"
                      roles: Scope
                      roles: Right
                      roles: Condition
                      roles: Try
                      startPosition {
                        line: 128
                        col: 36
                      }
                      endPosition {
                        line: 128
                        col: 41
                      }
                      children {
                        internalType: "SimpleName"
                        roles: Scope
                        roles: Right
                        roles: Condition
                        roles: Try
                        startPosition {
                          line: 128
                          col: 36
                        }
                        endPosition {
                          line: 128
                          col: 41
                        }
                        token: "titles"
                      }
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Right
                      roles: Condition
                      roles: Identifier
                      roles: Try
                      startPosition {
                        line: 128
                        col: 43
                      }
                      endPosition {
                        line: 128
                        col: 48
                      }
                      token: "length"
                    }
                    token: "FieldAccess:length"
                  }
                  token: "LESS"
                }
                children {
                  internalType: "UnaryExpr"
                  roles: Try
                  roles: Update
                  startPosition {
                    line: 128
                    col: 51
                  }
                  endPosition {
                    line: 128
                    col: 53
                  }
                  children {
                    internalType: "NameExpr"
                    roles: Identifier
                    roles: Try
                    roles: Update
                    startPosition {
                      line: 128
                      col: 51
                    }
                    endPosition {
                      line: 128
                      col: 51
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Identifier
                      roles: Try
                      roles: Update
                      startPosition {
                        line: 128
                        col: 51
                      }
                      endPosition {
                        line: 128
                        col: 51
                      }
                      token: "j"
                    }
                  }
                  token: "POSTFIX_INCREMENT"
                }
                children {
                  internalType: "BlockStmt"
                  roles: Try
                  startPosition {
                    line: 128
                    col: 56
                  }
                  endPosition {
                    line: 136
                    col: 17
                  }
                  children {
                    internalType: "ExpressionStmt"
                    roles: Try
                    startPosition {
                      line: 129
                      col: 21
                    }
                    endPosition {
                      line: 129
                      col: 75
                    }
                    children {
                      internalType: "VariableDeclarationExpr"
                      roles: Try
                      startPosition {
                        line: 129
                        col: 21
                      }
                      endPosition {
                        line: 129
                        col: 74
                      }
                      children {
                        internalType: "VariableDeclarator"
                        roles: Declaration
                        roles: Try
                        startPosition {
                          line: 129
                          col: 29
                        }
                        endPosition {
                          line: 129
                          col: 74
                        }
                        children {
                          internalType: "ClassOrInterfaceType"
                          roles: Type
                          roles: Declaration
                          roles: Try
                          startPosition {
                            line: 129
                            col: 21
                          }
                          endPosition {
                            line: 129
                            col: 27
                          }
                          children {
                            internalType: "SimpleName"
                            roles: Type
                            roles: Declaration
                            roles: Try
                            startPosition {
                              line: 129
                              col: 21
                            }
                            endPosition {
                              line: 129
                              col: 27
                            }
                            token: "Scanner"
                          }
                          token: "Type:Scanner"
                        }
                        children {
                          internalType: "SimpleName"
                          roles: Identifier
                          roles: Declaration
                          roles: Try
                          startPosition {
                            line: 129
                            col: 29
                          }
                          endPosition {
                            line: 129
                            col: 39
                          }
                          token: "fileScanner"
                        }
                        children {
                          internalType: "ObjectCreationExpr"
                          roles: Declaration
                          roles: Try
                          startPosition {
                            line: 129
                            col: 43
                          }
                          endPosition {
                            line: 129
                            col: 74
                          }
                          children {
                            internalType: "ClassOrInterfaceType"
                            roles: Type
                            roles: Declaration
                            roles: Try
                            startPosition {
                              line: 129
                              col: 47
                            }
                            endPosition {
                              line: 129
                              col: 53
                            }
                            children {
                              internalType: "SimpleName"
                              roles: Type
                              roles: Declaration
                              roles: Try
                              startPosition {
                                line: 129
                                col: 47
                              }
                              endPosition {
                                line: 129
                                col: 53
                              }
                              token: "Scanner"
                            }
                            token: "Type:Scanner"
                          }
                          children {
                            internalType: "ObjectCreationExpr"
                            roles: Argument
                            roles: Declaration
                            roles: Try
                            startPosition {
                              line: 129
                              col: 55
                            }
                            endPosition {
                              line: 129
                              col: 73
                            }
                            children {
                              internalType: "ClassOrInterfaceType"
                              roles: Type
                              roles: Argument
                              roles: Declaration
                              roles: Try
                              startPosition {
                                line: 129
                                col: 59
                              }
                              endPosition {
                                line: 129
                                col: 62
                              }
                              children {
                                internalType: "SimpleName"
                                roles: Type
                                roles: Argument
                                roles: Declaration
                                roles: Try
                                startPosition {
                                  line: 129
                                  col: 59
                                }
                                endPosition {
                                  line: 129
                                  col: 62
                                }
                                token: "File"
                              }
                              token: "Type:File"
                            }
                            children {
                              internalType: "ArrayAccessExpr"
                              roles: Argument
                              roles: Declaration
                              roles: Try
                              startPosition {
                                line: 129
                                col: 64
                              }
                              endPosition {
                                line: 129
                                col: 72
                              }
                              children {
                                internalType: "NameExpr"
                                roles: Argument
                                roles: Identifier
                                roles: Declaration
                                roles: Try
                                startPosition {
                                  line: 129
                                  col: 64
                                }
                                endPosition {
                                  line: 129
                                  col: 69
                                }
                                children {
                                  internalType: "SimpleName"
                                  roles: Argument
                                  roles: Identifier
                                  roles: Declaration
                                  roles: Try
                                  startPosition {
                                    line: 129
                                    col: 64
                                  }
                                  endPosition {
                                    line: 129
                                    col: 69
                                  }
                                  token: "titles"
                                }
                              }
                              children {
                                internalType: "NameExpr"
                                roles: Literal
                                roles: Argument
                                roles: Declaration
                                roles: Try
                                startPosition {
                                  line: 129
                                  col: 71
                                }
                                endPosition {
                                  line: 129
                                  col: 71
                                }
                                children {
                                  internalType: "SimpleName"
                                  roles: Literal
                                  roles: Argument
                                  roles: Declaration
                                  roles: Try
                                  startPosition {
                                    line: 129
                                    col: 71
                                  }
                                  endPosition {
                                    line: 129
                                    col: 71
                                  }
                                  token: "j"
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                  children {
                    internalType: "ExpressionStmt"
                    roles: Try
                    startPosition {
                      line: 130
                      col: 21
                    }
                    endPosition {
                      line: 130
                      col: 51
                    }
                    children {
                      internalType: "VariableDeclarationExpr"
                      roles: Try
                      startPosition {
                        line: 130
                        col: 21
                      }
                      endPosition {
                        line: 130
                        col: 50
                      }
                      children {
                        internalType: "VariableDeclarator"
                        roles: Declaration
                        roles: Try
                        startPosition {
                          line: 130
                          col: 31
                        }
                        endPosition {
                          line: 130
                          col: 50
                        }
                        children {
                          internalType: "ClassOrInterfaceType"
                          roles: Type
                          roles: Declaration
                          roles: Try
                          startPosition {
                            line: 130
                            col: 21
                          }
                          endPosition {
                            line: 130
                            col: 29
                          }
                          children {
                            internalType: "SimpleName"
                            roles: Type
                            roles: Declaration
                            roles: Try
                            startPosition {
                              line: 130
                              col: 21
                            }
                            endPosition {
                              line: 130
                              col: 29
                            }
                            token: "Stopwatch"
                          }
                          token: "Type:Stopwatch"
                        }
                        children {
                          internalType: "SimpleName"
                          roles: Identifier
                          roles: Declaration
                          roles: Try
                          startPosition {
                            line: 130
                            col: 31
                          }
                          endPosition {
                            line: 130
                            col: 32
                          }
                          token: "st"
                        }
                        children {
                          internalType: "ObjectCreationExpr"
                          roles: Declaration
                          roles: Try
                          startPosition {
                            line: 130
                            col: 36
                          }
                          endPosition {
                            line: 130
                            col: 50
                          }
                          children {
                            internalType: "ClassOrInterfaceType"
                            roles: Type
                            roles: Declaration
                            roles: Try
                            startPosition {
                              line: 130
                              col: 40
                            }
                            endPosition {
                              line: 130
                              col: 48
                            }
                            children {
                              internalType: "SimpleName"
                              roles: Type
                              roles: Declaration
                              roles: Try
                              startPosition {
                                line: 130
                                col: 40
                              }
                              endPosition {
                                line: 130
                                col: 48
                              }
                              token: "Stopwatch"
                            }
                            token: "Type:Stopwatch"
                          }
                        }
                      }
                    }
                  }
                  children {
                    internalType: "ExpressionStmt"
                    roles: Try
                    startPosition {
                      line: 131
                      col: 21
                    }
                    endPosition {
                      line: 131
                      col: 31
                    }
                    children {
                      internalType: "MethodCallExpr"
                      roles: Try
                      startPosition {
                        line: 131
                        col: 21
                      }
                      endPosition {
                        line: 131
                        col: 30
                      }
                      children {
                        internalType: "NameExpr"
                        roles: Callee
                        roles: Try
                        startPosition {
                          line: 131
                          col: 21
                        }
                        endPosition {
                          line: 131
                          col: 22
                        }
                        children {
                          internalType: "SimpleName"
                          roles: Callee
                          roles: Try
                          startPosition {
                            line: 131
                            col: 21
                          }
                          endPosition {
                            line: 131
                            col: 22
                          }
                          token: "st"
                        }
                      }
                      children {
                        internalType: "SimpleName"
                        roles: Call
                        roles: Try
                        startPosition {
                          line: 131
                          col: 24
                        }
                        endPosition {
                          line: 131
                          col: 28
                        }
                        token: "start"
                      }
                      token: "MethodCall:start"
                    }
                  }
                  children {
                    internalType: "ExpressionStmt"
                    roles: Try
                    startPosition {
                      line: 132
                      col: 21
                    }
                    endPosition {
                      line: 132
                      col: 83
                    }
                    children {
                      internalType: "VariableDeclarationExpr"
                      roles: Try
                      startPosition {
                        line: 132
                        col: 21
                      }
                      endPosition {
                        line: 132
                        col: 82
                      }
                      children {
                        internalType: "VariableDeclarator"
                        roles: Declaration
                        roles: Try
                        startPosition {
                          line: 132
                          col: 39
                        }
                        endPosition {
                          line: 132
                          col: 82
                        }
                        children {
                          internalType: "ClassOrInterfaceType"
                          roles: Type
                          roles: Declaration
                          roles: Try
                          startPosition {
                            line: 132
                            col: 21
                          }
                          endPosition {
                            line: 132
                            col: 37
                          }
                          children {
                            internalType: "SimpleName"
                            roles: Type
                            roles: Declaration
                            roles: Try
                            startPosition {
                              line: 132
                              col: 21
                            }
                            endPosition {
                              line: 132
                              col: 29
                            }
                            token: "ArrayList"
                          }
                          children {
                            internalType: "ClassOrInterfaceType"
                            roles: Type
                            roles: Argument
                            roles: Declaration
                            roles: Try
                            startPosition {
                              line: 132
                              col: 31
                            }
                            endPosition {
                              line: 132
                              col: 36
                            }
                            children {
                              internalType: "SimpleName"
                              roles: Type
                              roles: Argument
                              roles: Declaration
                              roles: Try
                              startPosition {
                                line: 132
                                col: 31
                              }
                              endPosition {
                                line: 132
                                col: 36
                              }
                              token: "String"
                            }
                            token: "Type:String"
                          }
                          token: "Type:ArrayList"
                        }
                        children {
                          internalType: "SimpleName"
                          roles: Identifier
                          roles: Declaration
                          roles: Try
                          startPosition {
                            line: 132
                            col: 39
                          }
                          endPosition {
                            line: 132
                            col: 43
                          }
                          token: "words"
                        }
                        children {
                          internalType: "MethodCallExpr"
                          roles: Declaration
                          roles: Try
                          startPosition {
                            line: 132
                            col: 47
                          }
                          endPosition {
                            line: 132
                            col: 82
                          }
                          children {
                            internalType: "SimpleName"
                            roles: Call
                            roles: Declaration
                            roles: Try
                            startPosition {
                              line: 132
                              col: 47
                            }
                            endPosition {
                              line: 132
                              col: 69
                            }
                            token: "countWordsWithArrayList"
                          }
                          children {
                            internalType: "NameExpr"
                            roles: Argument
                            roles: Declaration
                            roles: Try
                            startPosition {
                              line: 132
                              col: 71
                            }
                            endPosition {
                              line: 132
                              col: 81
                            }
                            children {
                              internalType: "SimpleName"
                              roles: Argument
                              roles: Declaration
                              roles: Try
                              startPosition {
                                line: 132
                                col: 71
                              }
                              endPosition {
                                line: 132
                                col: 81
                              }
                              token: "fileScanner"
                            }
                          }
                          token: "MethodCall:countWordsWithArrayList"
                        }
                      }
                    }
                  }
                  children {
                    internalType: "ExpressionStmt"
                    roles: Try
                    startPosition {
                      line: 133
                      col: 21
                    }
                    endPosition {
                      line: 133
                      col: 30
                    }
                    children {
                      internalType: "MethodCallExpr"
                      roles: Try
                      startPosition {
                        line: 133
                        col: 21
                      }
                      endPosition {
                        line: 133
                        col: 29
                      }
                      children {
                        internalType: "NameExpr"
                        roles: Callee
                        roles: Try
                        startPosition {
                          line: 133
                          col: 21
                        }
                        endPosition {
                          line: 133
                          col: 22
                        }
                        children {
                          internalType: "SimpleName"
                          roles: Callee
                          roles: Try
                          startPosition {
                            line: 133
                            col: 21
                          }
                          endPosition {
                            line: 133
                            col: 22
                          }
                          token: "st"
                        }
                      }
                      children {
                        internalType: "SimpleName"
                        roles: Call
                        roles: Try
                        startPosition {
                          line: 133
                          col: 24
                        }
                        endPosition {
                          line: 133
                          col: 27
                        }
                        token: "stop"
                      }
                      token: "MethodCall:stop"
                    }
                  }
                  children {
                    internalType: "ExpressionStmt"
                    roles: Try
                    startPosition {
                      line: 134
                      col: 21
                    }
                    endPosition {
                      line: 134
                      col: 42
                    }
                    children {
                      internalType: "AssignExpr"
                      roles: Try
                      startPosition {
                        line: 134
                        col: 21
                      }
                      endPosition {
                        line: 134
                        col: 41
                      }
                      children {
                        internalType: "ArrayAccessExpr"
                        roles: Try
                        roles: Left
                        startPosition {
                          line: 134
                          col: 21
                        }
                        endPosition {
                          line: 134
                          col: 28
                        }
                        children {
                          internalType: "NameExpr"
                          roles: Identifier
                          roles: Try
                          roles: Left
                          startPosition {
                            line: 134
                            col: 21
                          }
                          endPosition {
                            line: 134
                            col: 25
                          }
                          children {
                            internalType: "SimpleName"
                            roles: Identifier
                            roles: Try
                            roles: Left
                            startPosition {
                              line: 134
                              col: 21
                            }
                            endPosition {
                              line: 134
                              col: 25
                            }
                            token: "times"
                          }
                        }
                        children {
                          internalType: "NameExpr"
                          roles: Literal
                          roles: Try
                          roles: Left
                          startPosition {
                            line: 134
                            col: 27
                          }
                          endPosition {
                            line: 134
                            col: 27
                          }
                          children {
                            internalType: "SimpleName"
                            roles: Literal
                            roles: Try
                            roles: Left
                            startPosition {
                              line: 134
                              col: 27
                            }
                            endPosition {
                              line: 134
                              col: 27
                            }
                            token: "j"
                          }
                        }
                      }
                      children {
                        internalType: "MethodCallExpr"
                        roles: Right
                        roles: Try
                        startPosition {
                          line: 134
                          col: 33
                        }
                        endPosition {
                          line: 134
                          col: 41
                        }
                        children {
                          internalType: "NameExpr"
                          roles: Callee
                          roles: Right
                          roles: Try
                          startPosition {
                            line: 134
                            col: 33
                          }
                          endPosition {
                            line: 134
                            col: 34
                          }
                          children {
                            internalType: "SimpleName"
                            roles: Callee
                            roles: Right
                            roles: Try
                            startPosition {
                              line: 134
                              col: 33
                            }
                            endPosition {
                              line: 134
                              col: 34
                            }
                            token: "st"
                          }
                        }
                        children {
                          internalType: "SimpleName"
                          roles: Call
                          roles: Right
                          roles: Try
                          startPosition {
                            line: 134
                            col: 36
                          }
                          endPosition {
                            line: 134
                            col: 39
                          }
                          token: "time"
                        }
                        token: "MethodCall:time"
                      }
                      token: "PLUS"
                    }
                  }
                  children {
                    internalType: "ExpressionStmt"
                    roles: Try
                    startPosition {
                      line: 135
                      col: 21
                    }
                    endPosition {
                      line: 135
                      col: 40
                    }
                    children {
                      internalType: "MethodCallExpr"
                      roles: Try
                      startPosition {
                        line: 135
                        col: 21
                      }
                      endPosition {
                        line: 135
                        col: 39
                      }
                      children {
                        internalType: "NameExpr"
                        roles: Callee
                        roles: Try
                        startPosition {
                          line: 135
                          col: 21
                        }
                        endPosition {
                          line: 135
                          col: 31
                        }
                        children {
                          internalType: "SimpleName"
                          roles: Callee
                          roles: Try
                          startPosition {
                            line: 135
                            col: 21
                          }
                          endPosition {
                            line: 135
                            col: 31
                          }
                          token: "fileScanner"
                        }
                      }
                      children {
                        internalType: "SimpleName"
                        roles: Call
                        roles: Try
                        startPosition {
                          line: 135
                          col: 33
                        }
                        endPosition {
                          line: 135
                          col: 37
                        }
                        token: "close"
                      }
                      token: "MethodCall:close"
                    }
                  }
                }
              }
            }
          }
          children {
            internalType: "ForStmt"
            roles: Try
            startPosition {
              line: 138
              col: 13
            }
            endPosition {
              line: 139
              col: 97
            }
            children {
              internalType: "VariableDeclarationExpr"
              roles: Initialization
              roles: Try
              startPosition {
                line: 138
                col: 17
              }
              endPosition {
                line: 138
                col: 25
              }
              children {
                internalType: "VariableDeclarator"
                roles: Initialization
                roles: Declaration
                roles: Try
                startPosition {
                  line: 138
                  col: 21
                }
                endPosition {
                  line: 138
                  col: 25
                }
                children {
                  internalType: "PrimitiveType"
                  roles: Type
                  roles: Initialization
                  roles: Declaration
                  roles: Try
                  startPosition {
                    line: 138
                    col: 17
                  }
                  endPosition {
                    line: 138
                    col: 19
                  }
                  token: "int"
                }
                children {
                  internalType: "SimpleName"
                  roles: Initialization
                  roles: Identifier
                  roles: Declaration
                  roles: Try
                  startPosition {
                    line: 138
                    col: 21
                  }
                  endPosition {
                    line: 138
                    col: 21
                  }
                  token: "i"
                }
                children {
                  internalType: "IntegerLiteralExpr"
                  roles: Initialization
                  roles: Declaration
                  roles: Try
                  startPosition {
                    line: 138
                    col: 25
                  }
                  endPosition {
                    line: 138
                    col: 25
                  }
                }
              }
            }
            children {
              internalType: "BinaryExpr"
              roles: Condition
              roles: Try
              startPosition {
                line: 138
                col: 28
              }
              endPosition {
                line: 138
                col: 44
              }
              children {
                internalType: "NameExpr"
                roles: Condition
                roles: Try
                roles: Left
                startPosition {
                  line: 138
                  col: 28
                }
                endPosition {
                  line: 138
                  col: 28
                }
                children {
                  internalType: "SimpleName"
                  roles: Condition
                  roles: Try
                  roles: Left
                  startPosition {
                    line: 138
                    col: 28
                  }
                  endPosition {
                    line: 138
                    col: 28
                  }
                  token: "i"
                }
              }
              children {
                internalType: "FieldAccessExpr"
                roles: Right
                roles: Condition
                roles: Try
                startPosition {
                  line: 138
                  col: 32
                }
                endPosition {
                  line: 138
                  col: 44
                }
                children {
                  internalType: "NameExpr"
                  roles: Scope
                  roles: Right
                  roles: Condition
                  roles: Try
                  startPosition {
                    line: 138
                    col: 32
                  }
                  endPosition {
                    line: 138
                    col: 37
                  }
                  children {
                    internalType: "SimpleName"
                    roles: Scope
                    roles: Right
                    roles: Condition
                    roles: Try
                    startPosition {
                      line: 138
                      col: 32
                    }
                    endPosition {
                      line: 138
                      col: 37
                    }
                    token: "titles"
                  }
                }
                children {
                  internalType: "SimpleName"
                  roles: Right
                  roles: Condition
                  roles: Identifier
                  roles: Try
                  startPosition {
                    line: 138
                    col: 39
                  }
                  endPosition {
                    line: 138
                    col: 44
                  }
                  token: "length"
                }
                token: "FieldAccess:length"
              }
              token: "LESS"
            }
            children {
              internalType: "UnaryExpr"
              roles: Try
              roles: Update
              startPosition {
                line: 138
                col: 47
              }
              endPosition {
                line: 138
                col: 49
              }
              children {
                internalType: "NameExpr"
                roles: Identifier
                roles: Try
                roles: Update
                startPosition {
                  line: 138
                  col: 47
                }
                endPosition {
                  line: 138
                  col: 47
                }
                children {
                  internalType: "SimpleName"
                  roles: Identifier
                  roles: Try
                  roles: Update
                  startPosition {
                    line: 138
                    col: 47
                  }
                  endPosition {
                    line: 138
                    col: 47
                  }
                  token: "i"
                }
              }
              token: "POSTFIX_INCREMENT"
            }
            children {
              internalType: "ExpressionStmt"
              roles: Try
              startPosition {
                line: 139
                col: 17
              }
              endPosition {
                line: 139
                col: 97
              }
              children {
                internalType: "MethodCallExpr"
                roles: Try
                startPosition {
                  line: 139
                  col: 17
                }
                endPosition {
                  line: 139
                  col: 96
                }
                children {
                  internalType: "FieldAccessExpr"
                  roles: Callee
                  roles: Try
                  startPosition {
                    line: 139
                    col: 17
                  }
                  endPosition {
                    line: 139
                    col: 26
                  }
                  children {
                    internalType: "NameExpr"
                    roles: Callee
                    roles: Scope
                    roles: Try
                    startPosition {
                      line: 139
                      col: 17
                    }
                    endPosition {
                      line: 139
                      col: 22
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Callee
                      roles: Scope
                      roles: Try
                      startPosition {
                        line: 139
                        col: 17
                      }
                      endPosition {
                        line: 139
                        col: 22
                      }
                      token: "System"
                    }
                  }
                  children {
                    internalType: "SimpleName"
                    roles: Callee
                    roles: Identifier
                    roles: Try
                    startPosition {
                      line: 139
                      col: 24
                    }
                    endPosition {
                      line: 139
                      col: 26
                    }
                    token: "out"
                  }
                  token: "FieldAccess:out"
                }
                children {
                  internalType: "SimpleName"
                  roles: Call
                  roles: Try
                  startPosition {
                    line: 139
                    col: 28
                  }
                  endPosition {
                    line: 139
                    col: 34
                  }
                  token: "println"
                }
                children {
                  internalType: "BinaryExpr"
                  roles: Argument
                  roles: Try
                  startPosition {
                    line: 139
                    col: 36
                  }
                  endPosition {
                    line: 139
                    col: 95
                  }
                  children {
                    internalType: "BinaryExpr"
                    roles: Argument
                    roles: Try
                    roles: Left
                    startPosition {
                      line: 139
                      col: 36
                    }
                    endPosition {
                      line: 139
                      col: 73
                    }
                    children {
                      internalType: "BinaryExpr"
                      roles: Argument
                      roles: Try
                      roles: Left
                      startPosition {
                        line: 139
                        col: 36
                      }
                      endPosition {
                        line: 139
                        col: 66
                      }
                      children {
                        internalType: "StringLiteralExpr"
                        roles: Argument
                        roles: Try
                        roles: Left
                        startPosition {
                          line: 139
                          col: 36
                        }
                        endPosition {
                          line: 139
                          col: 54
                        }
                        token: "Average time for "
                      }
                      children {
                        internalType: "ArrayAccessExpr"
                        roles: Argument
                        roles: Right
                        roles: Try
                        roles: Left
                        startPosition {
                          line: 139
                          col: 58
                        }
                        endPosition {
                          line: 139
                          col: 66
                        }
                        children {
                          internalType: "NameExpr"
                          roles: Argument
                          roles: Right
                          roles: Identifier
                          roles: Try
                          roles: Left
                          startPosition {
                            line: 139
                            col: 58
                          }
                          endPosition {
                            line: 139
                            col: 63
                          }
                          children {
                            internalType: "SimpleName"
                            roles: Argument
                            roles: Right
                            roles: Identifier
                            roles: Try
                            roles: Left
                            startPosition {
                              line: 139
                              col: 58
                            }
                            endPosition {
                              line: 139
                              col: 63
                            }
                            token: "titles"
                          }
                        }
                        children {
                          internalType: "NameExpr"
                          roles: Literal
                          roles: Argument
                          roles: Right
                          roles: Try
                          roles: Left
                          startPosition {
                            line: 139
                            col: 65
                          }
                          endPosition {
                            line: 139
                            col: 65
                          }
                          children {
                            internalType: "SimpleName"
                            roles: Literal
                            roles: Argument
                            roles: Right
                            roles: Try
                            roles: Left
                            startPosition {
                              line: 139
                              col: 65
                            }
                            endPosition {
                              line: 139
                              col: 65
                            }
                            token: "i"
                          }
                        }
                      }
                      token: "PLUS"
                    }
                    children {
                      internalType: "StringLiteralExpr"
                      roles: Argument
                      roles: Right
                      roles: Try
                      roles: Left
                      startPosition {
                        line: 139
                        col: 70
                      }
                      endPosition {
                        line: 139
                        col: 73
                      }
                      token: ": "
                    }
                    token: "PLUS"
                  }
                  children {
                    internalType: "EnclosedExpr"
                    roles: Argument
                    roles: Right
                    roles: Try
                    startPosition {
                      line: 139
                      col: 77
                    }
                    endPosition {
                      line: 139
                      col: 95
                    }
                    children {
                      internalType: "BinaryExpr"
                      roles: Argument
                      roles: Right
                      roles: Try
                      startPosition {
                        line: 139
                        col: 78
                      }
                      endPosition {
                        line: 139
                        col: 94
                      }
                      children {
                        internalType: "ArrayAccessExpr"
                        roles: Argument
                        roles: Right
                        roles: Try
                        roles: Left
                        startPosition {
                          line: 139
                          col: 78
                        }
                        endPosition {
                          line: 139
                          col: 85
                        }
                        children {
                          internalType: "NameExpr"
                          roles: Argument
                          roles: Right
                          roles: Identifier
                          roles: Try
                          roles: Left
                          startPosition {
                            line: 139
                            col: 78
                          }
                          endPosition {
                            line: 139
                            col: 82
                          }
                          children {
                            internalType: "SimpleName"
                            roles: Argument
                            roles: Right
                            roles: Identifier
                            roles: Try
                            roles: Left
                            startPosition {
                              line: 139
                              col: 78
                            }
                            endPosition {
                              line: 139
                              col: 82
                            }
                            token: "times"
                          }
                        }
                        children {
                          internalType: "NameExpr"
                          roles: Literal
                          roles: Argument
                          roles: Right
                          roles: Try
                          roles: Left
                          startPosition {
                            line: 139
                            col: 84
                          }
                          endPosition {
                            line: 139
                            col: 84
                          }
                          children {
                            internalType: "SimpleName"
                            roles: Literal
                            roles: Argument
                            roles: Right
                            roles: Try
                            roles: Left
                            startPosition {
                              line: 139
                              col: 84
                            }
                            endPosition {
                              line: 139
                              col: 84
                            }
                            token: "i"
                          }
                        }
                      }
                      children {
                        internalType: "NameExpr"
                        roles: Argument
                        roles: Right
                        roles: Try
                        startPosition {
                          line: 139
                          col: 89
                        }
                        endPosition {
                          line: 139
                          col: 94
                        }
                        children {
                          internalType: "SimpleName"
                          roles: Argument
                          roles: Right
                          roles: Try
                          startPosition {
                            line: 139
                            col: 89
                          }
                          endPosition {
                            line: 139
                            col: 94
                          }
                          token: "numExp"
                        }
                      }
                      token: "DIVIDE"
                    }
                  }
                  token: "PLUS"
                }
                token: "MethodCall:println"
              }
            }
          }
        }
        children {
          internalType: "CatchClause"
          startPosition {
            line: 141
            col: 9
          }
          endPosition {
            line: 143
            col: 9
          }
          children {
            internalType: "Parameter"
            roles: Argument
            startPosition {
              line: 141
              col: 15
            }
            endPosition {
              line: 141
              col: 37
            }
            children {
              internalType: "ClassOrInterfaceType"
              roles: Type
              roles: Argument
              startPosition {
                line: 141
                col: 15
              }
              endPosition {
                line: 141
                col: 35
              }
              children {
                internalType: "SimpleName"
                roles: Type
                roles: Argument
                startPosition {
                  line: 141
                  col: 15
                }
                endPosition {
                  line: 141
                  col: 35
                }
                token: "FileNotFoundException"
              }
              token: "Type:FileNotFoundException"
            }
            children {
              internalType: "SimpleName"
              roles: Argument
              roles: Identifier
              startPosition {
                line: 141
                col: 37
              }
              endPosition {
                line: 141
                col: 37
              }
              token: "e"
            }
          }
          children {
            internalType: "BlockStmt"
            roles: Catch
            startPosition {
              line: 141
              col: 40
            }
            endPosition {
              line: 143
              col: 9
            }
            children {
              internalType: "ExpressionStmt"
              roles: Catch
              startPosition {
                line: 142
                col: 13
              }
              endPosition {
                line: 142
                col: 90
              }
              children {
                internalType: "MethodCallExpr"
                roles: Catch
                startPosition {
                  line: 142
                  col: 13
                }
                endPosition {
                  line: 142
                  col: 89
                }
                children {
                  internalType: "FieldAccessExpr"
                  roles: Callee
                  roles: Catch
                  startPosition {
                    line: 142
                    col: 13
                  }
                  endPosition {
                    line: 142
                    col: 22
                  }
                  children {
                    internalType: "NameExpr"
                    roles: Callee
                    roles: Scope
                    roles: Catch
                    startPosition {
                      line: 142
                      col: 13
                    }
                    endPosition {
                      line: 142
                      col: 18
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Callee
                      roles: Scope
                      roles: Catch
                      startPosition {
                        line: 142
                        col: 13
                      }
                      endPosition {
                        line: 142
                        col: 18
                      }
                      token: "System"
                    }
                  }
                  children {
                    internalType: "SimpleName"
                    roles: Callee
                    roles: Identifier
                    roles: Catch
                    startPosition {
                      line: 142
                      col: 20
                    }
                    endPosition {
                      line: 142
                      col: 22
                    }
                    token: "out"
                  }
                  token: "FieldAccess:out"
                }
                children {
                  internalType: "SimpleName"
                  roles: Call
                  roles: Catch
                  startPosition {
                    line: 142
                    col: 24
                  }
                  endPosition {
                    line: 142
                    col: 30
                  }
                  token: "println"
                }
                children {
                  internalType: "BinaryExpr"
                  roles: Argument
                  roles: Catch
                  startPosition {
                    line: 142
                    col: 32
                  }
                  endPosition {
                    line: 142
                    col: 88
                  }
                  children {
                    internalType: "StringLiteralExpr"
                    roles: Argument
                    roles: Catch
                    roles: Left
                    startPosition {
                      line: 142
                      col: 32
                    }
                    endPosition {
                      line: 142
                      col: 84
                    }
                    token: "Problem reading the data file. Exiting the program."
                  }
                  children {
                    internalType: "NameExpr"
                    roles: Argument
                    roles: Right
                    roles: Catch
                    startPosition {
                      line: 142
                      col: 88
                    }
                    endPosition {
                      line: 142
                      col: 88
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Argument
                      roles: Right
                      roles: Catch
                      startPosition {
                        line: 142
                        col: 88
                      }
                      endPosition {
                        line: 142
                        col: 88
                      }
                      token: "e"
                    }
                  }
                  token: "PLUS"
                }
                token: "MethodCall:println"
              }
            }
          }
        }
      }
    }
  }
  children {
    internalType: "MethodDeclaration"
    startPosition {
      line: 148
      col: 5
    }
    endPosition {
      line: 156
      col: 5
    }
    children {
      internalType: "Modifier"
      startPosition {
        line: 148
        col: 5
      }
      endPosition {
        line: 156
        col: 5
      }
      token: "private"
    }
    children {
      internalType: "Modifier"
      startPosition {
        line: 148
        col: 5
      }
      endPosition {
        line: 156
        col: 5
      }
      token: "static"
    }
    children {
      internalType: "SimpleName"
      startPosition {
        line: 148
        col: 25
      }
      endPosition {
        line: 148
        col: 38
      }
      token: "setLookAndFeel"
    }
    children {
      internalType: "VoidType"
      startPosition {
        line: 148
        col: 20
      }
      endPosition {
        line: 148
        col: 23
      }
      token: "void"
    }
    children {
      internalType: "BlockStmt"
      startPosition {
        line: 148
        col: 42
      }
      endPosition {
        line: 156
        col: 5
      }
      children {
        internalType: "TryStmt"
        startPosition {
          line: 149
          col: 9
        }
        endPosition {
          line: 155
          col: 9
        }
        children {
          internalType: "BlockStmt"
          roles: Try
          startPosition {
            line: 149
            col: 13
          }
          endPosition {
            line: 151
            col: 9
          }
          children {
            internalType: "ExpressionStmt"
            roles: Try
            startPosition {
              line: 150
              col: 13
            }
            endPosition {
              line: 150
              col: 80
            }
            children {
              internalType: "MethodCallExpr"
              roles: Try
              startPosition {
                line: 150
                col: 13
              }
              endPosition {
                line: 150
                col: 79
              }
              children {
                internalType: "NameExpr"
                roles: Callee
                roles: Try
                startPosition {
                  line: 150
                  col: 13
                }
                endPosition {
                  line: 150
                  col: 21
                }
                children {
                  internalType: "SimpleName"
                  roles: Callee
                  roles: Try
                  startPosition {
                    line: 150
                    col: 13
                  }
                  endPosition {
                    line: 150
                    col: 21
                  }
                  token: "UIManager"
                }
              }
              children {
                internalType: "SimpleName"
                roles: Call
                roles: Try
                startPosition {
                  line: 150
                  col: 23
                }
                endPosition {
                  line: 150
                  col: 36
                }
                token: "setLookAndFeel"
              }
              children {
                internalType: "MethodCallExpr"
                roles: Argument
                roles: Try
                startPosition {
                  line: 150
                  col: 38
                }
                endPosition {
                  line: 150
                  col: 78
                }
                children {
                  internalType: "NameExpr"
                  roles: Argument
                  roles: Callee
                  roles: Try
                  startPosition {
                    line: 150
                    col: 38
                  }
                  endPosition {
                    line: 150
                    col: 46
                  }
                  children {
                    internalType: "SimpleName"
                    roles: Argument
                    roles: Callee
                    roles: Try
                    startPosition {
                      line: 150
                      col: 38
                    }
                    endPosition {
                      line: 150
                      col: 46
                    }
                    token: "UIManager"
                  }
                }
                children {
                  internalType: "SimpleName"
                  roles: Call
                  roles: Argument
                  roles: Try
                  startPosition {
                    line: 150
                    col: 48
                  }
                  endPosition {
                    line: 150
                    col: 76
                  }
                  token: "getSystemLookAndFeelClassName"
                }
                token: "MethodCall:getSystemLookAndFeelClassName"
              }
              token: "MethodCall:setLookAndFeel"
            }
          }
        }
        children {
          internalType: "CatchClause"
          startPosition {
            line: 152
            col: 9
          }
          endPosition {
            line: 155
            col: 9
          }
          children {
            internalType: "Parameter"
            roles: Argument
            startPosition {
              line: 152
              col: 15
            }
            endPosition {
              line: 152
              col: 25
            }
            children {
              internalType: "ClassOrInterfaceType"
              roles: Type
              roles: Argument
              startPosition {
                line: 152
                col: 15
              }
              endPosition {
                line: 152
                col: 23
              }
              children {
                internalType: "SimpleName"
                roles: Type
                roles: Argument
                startPosition {
                  line: 152
                  col: 15
                }
                endPosition {
                  line: 152
                  col: 23
                }
                token: "Exception"
              }
              token: "Type:Exception"
            }
            children {
              internalType: "SimpleName"
              roles: Argument
              roles: Identifier
              startPosition {
                line: 152
                col: 25
              }
              endPosition {
                line: 152
                col: 25
              }
              token: "e"
            }
          }
          children {
            internalType: "BlockStmt"
            roles: Catch
            startPosition {
              line: 152
              col: 28
            }
            endPosition {
              line: 155
              col: 9
            }
            children {
              internalType: "ExpressionStmt"
              roles: Catch
              startPosition {
                line: 153
                col: 13
              }
              endPosition {
                line: 154
                col: 59
              }
              children {
                internalType: "MethodCallExpr"
                roles: Catch
                startPosition {
                  line: 153
                  col: 13
                }
                endPosition {
                  line: 154
                  col: 58
                }
                children {
                  internalType: "FieldAccessExpr"
                  roles: Callee
                  roles: Catch
                  startPosition {
                    line: 153
                    col: 13
                  }
                  endPosition {
                    line: 153
                    col: 22
                  }
                  children {
                    internalType: "NameExpr"
                    roles: Callee
                    roles: Scope
                    roles: Catch
                    startPosition {
                      line: 153
                      col: 13
                    }
                    endPosition {
                      line: 153
                      col: 18
                    }
                    children {
                      internalType: "SimpleName"
                      roles: Callee
                      roles: Scope
                      roles: Catch
                      startPosition {
                        line: 153
                        col: 13
                      }
                      endPosition {
                        line: 153
                        col: 18
                      }
                      token: "System"
                    }
                  }
                  children {
                    internalType: "SimpleName"
                    roles: Callee
                    roles: Identifier
                    roles: Catch
                    startPosition {
                      line: 153
                      col: 20
                    }
                    endPosition {
                      line: 153
                      col: 22
                    }
                    token: "out"
                  }
                  token: "FieldAccess:out"
                }
                children {
                  internalType: "SimpleName"
                  roles: Call
                  roles: Catch
                  startPosition {
                    line: 153
                    col: 24
                  }
                  endPosition {
                    line: 153
                    col: 30
                  }
                  token: "println"
                }
                children {
                  internalType: "BinaryExpr"
                  roles: Argument
                  roles: Catch
                  startPosition {
                    line: 153
                    col: 32
                  }
                  endPosition {
                    line: 154
                    col: 57
                  }
                  children {
                    internalType: "StringLiteralExpr"
                    roles: Argument
                    roles: Catch
                    roles: Left
                    startPosition {
                      line: 153
                      col: 32
                    }
                    endPosition {
                      line: 153
                      col: 79
                    }
                    token: "Unable to set look at feel to local settings. "
                  }
                  children {
                    internalType: "StringLiteralExpr"
                    roles: Argument
                    roles: Right
                    roles: Catch
                    startPosition {
                      line: 154
                      col: 13
                    }
                    endPosition {
                      line: 154
                      col: 57
                    }
                    token: "Continuing with default Java look and feel."
                  }
                  token: "PLUS"
                }
                token: "MethodCall:println"
              }
            }
          }
        }
      }
    }
  }
  children {
    internalType: "MethodDeclaration"
    startPosition {
      line: 162
      col: 5
    }
    endPosition {
      line: 172
      col: 5
    }
    children {
      internalType: "Modifier"
      startPosition {
        line: 162
        col: 5
      }
      endPosition {
        line: 172
        col: 5
      }
      token: "private"
    }
    children {
      internalType: "Modifier"
      startPosition {
        line: 162
        col: 5
      }
      endPosition {
        line: 172
        col: 5
      }
      token: "static"
    }
    children {
      internalType: "SimpleName"
      startPosition {
        line: 162
        col: 25
      }
      endPosition {
        line: 162
        col: 31
      }
      token: "getFile"
    }
    children {
      internalType: "ClassOrInterfaceType"
      roles: Type
      startPosition {
        line: 162
        col: 20
      }
      endPosition {
        line: 162
        col: 23
      }
      children {
        internalType: "SimpleName"
        roles: Type
        startPosition {
          line: 162
          col: 20
        }
        endPosition {
          line: 162
          col: 23
        }
        token: "File"
      }
      token: "Type:File"
    }
    children {
      internalType: "BlockStmt"
      startPosition {
        line: 162
        col: 35
      }
      endPosition {
        line: 172
        col: 5
      }
      children {
        internalType: "ExpressionStmt"
        startPosition {
          line: 164
          col: 9
        }
        endPosition {
          line: 164
          col: 53
        }
        children {
          internalType: "VariableDeclarationExpr"
          startPosition {
            line: 164
            col: 9
          }
          endPosition {
            line: 164
            col: 52
          }
          children {
            internalType: "VariableDeclarator"
            roles: Declaration
            startPosition {
              line: 164
              col: 22
            }
            endPosition {
              line: 164
              col: 52
            }
            children {
              internalType: "ClassOrInterfaceType"
              roles: Type
              roles: Declaration
              startPosition {
                line: 164
                col: 9
              }
              endPosition {
                line: 164
                col: 20
              }
              children {
                internalType: "SimpleName"
                roles: Type
                roles: Declaration
                startPosition {
                  line: 164
                  col: 9
                }
                endPosition {
                  line: 164
                  col: 20
                }
                token: "JFileChooser"
              }
              token: "Type:JFileChooser"
            }
            children {
              internalType: "SimpleName"
              roles: Identifier
              roles: Declaration
              startPosition {
                line: 164
                col: 22
              }
              endPosition {
                line: 164
                col: 28
              }
              token: "chooser"
            }
            children {
              internalType: "ObjectCreationExpr"
              roles: Declaration
              startPosition {
                line: 164
                col: 32
              }
              endPosition {
                line: 164
                col: 52
              }
              children {
                internalType: "ClassOrInterfaceType"
                roles: Type
                roles: Declaration
                startPosition {
                  line: 164
                  col: 36
                }
                endPosition {
                  line: 164
                  col: 47
                }
                children {
                  internalType: "SimpleName"
                  roles: Type
                  roles: Declaration
                  startPosition {
                    line: 164
                    col: 36
                  }
                  endPosition {
                    line: 164
                    col: 47
                  }
                  token: "JFileChooser"
                }
                token: "Type:JFileChooser"
              }
              children {
                internalType: "StringLiteralExpr"
                roles: Argument
                roles: Declaration
                startPosition {
                  line: 164
                  col: 49
                }
                endPosition {
                  line: 164
                  col: 51
                }
                token: "."
              }
            }
          }
        }
      }
      children {
        internalType: "ExpressionStmt"
        startPosition {
          line: 165
          col: 9
        }
        endPosition {
          line: 165
          col: 62
        }
        children {
          internalType: "MethodCallExpr"
          startPosition {
            line: 165
            col: 9
          }
          endPosition {
            line: 165
            col: 61
          }
          children {
            internalType: "NameExpr"
            roles: Callee
            startPosition {
              line: 165
              col: 9
            }
            endPosition {
              line: 165
              col: 15
            }
            children {
              internalType: "SimpleName"
              roles: Callee
              startPosition {
                line: 165
                col: 9
              }
              endPosition {
                line: 165
                col: 15
              }
              token: "chooser"
            }
          }
          children {
            internalType: "SimpleName"
            roles: Call
            startPosition {
              line: 165
              col: 17
            }
            endPosition {
              line: 165
              col: 30
            }
            token: "setDialogTitle"
          }
          children {
            internalType: "StringLiteralExpr"
            roles: Argument
            startPosition {
              line: 165
              col: 32
            }
            endPosition {
              line: 165
              col: 60
            }
            token: "Select File To Count Words:"
          }
          token: "MethodCall:setDialogTitle"
        }
      }
      children {
        internalType: "ExpressionStmt"
        startPosition {
          line: 166
          col: 9
        }
        endPosition {
          line: 166
          col: 50
        }
        children {
          internalType: "VariableDeclarationExpr"
          startPosition {
            line: 166
            col: 9
          }
          endPosition {
            line: 166
            col: 49
          }
          children {
            internalType: "VariableDeclarator"
            roles: Declaration
            startPosition {
              line: 166
              col: 13
            }
            endPosition {
              line: 166
              col: 49
            }
            children {
              internalType: "PrimitiveType"
              roles: Type
              roles: Declaration
              startPosition {
                line: 166
                col: 9
              }
              endPosition {
                line: 166
                col: 11
              }
              token: "int"
            }
            children {
              internalType: "SimpleName"
              roles: Identifier
              roles: Declaration
              startPosition {
                line: 166
                col: 13
              }
              endPosition {
                line: 166
                col: 18
              }
              token: "retval"
            }
            children {
              internalType: "MethodCallExpr"
              roles: Declaration
              startPosition {
                line: 166
                col: 22
              }
              endPosition {
                line: 166
                col: 49
              }
              children {
                internalType: "NameExpr"
                roles: Callee
                roles: Declaration
                startPosition {
                  line: 166
                  col: 22
                }
                endPosition {
                  line: 166
                  col: 28
                }
                children {
                  internalType: "SimpleName"
                  roles: Callee
                  roles: Declaration
                  startPosition {
                    line: 166
                    col: 22
                  }
                  endPosition {
                    line: 166
                    col: 28
                  }
                  token: "chooser"
                }
              }
              children {
                internalType: "SimpleName"
                roles: Call
                roles: Declaration
                startPosition {
                  line: 166
                  col: 30
                }
                endPosition {
                  line: 166
                  col: 43
                }
                token: "showOpenDialog"
              }
              children {
                internalType: "NullLiteralExpr"
                roles: Argument
                roles: Declaration
                startPosition {
                  line: 166
                  col: 45
                }
                endPosition {
                  line: 166
                  col: 48
                }
              }
              token: "MethodCall:showOpenDialog"
            }
          }
        }
      }
      children {
        internalType: "ExpressionStmt"
        startPosition {
          line: 167
          col: 9
        }
        endPosition {
          line: 167
          col: 21
        }
        children {
          internalType: "VariableDeclarationExpr"
          startPosition {
            line: 167
            col: 9
          }
          endPosition {
            line: 167
            col: 20
          }
          children {
            internalType: "VariableDeclarator"
            roles: Declaration
            startPosition {
              line: 167
              col: 14
            }
            endPosition {
              line: 167
              col: 20
            }
            children {
              internalType: "ClassOrInterfaceType"
              roles: Type
              roles: Declaration
              startPosition {
                line: 167
                col: 9
              }
              endPosition {
                line: 167
                col: 12
              }
              children {
                internalType: "SimpleName"
                roles: Type
                roles: Declaration
                startPosition {
                  line: 167
                  col: 9
                }
                endPosition {
                  line: 167
                  col: 12
                }
                token: "File"
              }
              token: "Type:File"
            }
            children {
              internalType: "SimpleName"
              roles: Identifier
              roles: Declaration
              startPosition {
                line: 167
                col: 14
              }
              endPosition {
                line: 167
                col: 14
              }
              token: "f"
            }
            children {
              internalType: "NullLiteralExpr"
              roles: Declaration
              startPosition {
                line: 167
                col: 17
              }
              endPosition {
                line: 167
                col: 20
              }
            }
          }
        }
      }
      children {
        internalType: "ExpressionStmt"
        startPosition {
          line: 168
          col: 9
        }
        endPosition {
          line: 168
          col: 28
        }
        children {
          internalType: "MethodCallExpr"
          startPosition {
            line: 168
            col: 9
          }
          endPosition {
            line: 168
            col: 27
          }
          children {
            internalType: "NameExpr"
            roles: Callee
            startPosition {
              line: 168
              col: 9
            }
            endPosition {
              line: 168
              col: 15
            }
            children {
              internalType: "SimpleName"
              roles: Callee
              startPosition {
                line: 168
                col: 9
              }
              endPosition {
                line: 168
                col: 15
              }
              token: "chooser"
            }
          }
          children {
            internalType: "SimpleName"
            roles: Call
            startPosition {
              line: 168
              col: 17
            }
            endPosition {
              line: 168
              col: 25
            }
            token: "grabFocus"
          }
          token: "MethodCall:grabFocus"
        }
      }
      children {
        internalType: "IfStmt"
        startPosition {
          line: 169
          col: 9
        }
        endPosition {
          line: 170
          col: 42
        }
        children {
          internalType: "BinaryExpr"
          roles: Condition
          startPosition {
            line: 169
            col: 13
          }
          endPosition {
            line: 169
            col: 49
          }
          children {
            internalType: "NameExpr"
            roles: Condition
            roles: Left
            startPosition {
              line: 169
              col: 13
            }
            endPosition {
              line: 169
              col: 18
            }
            children {
              internalType: "SimpleName"
              roles: Condition
              roles: Left
              startPosition {
                line: 169
                col: 13
              }
              endPosition {
                line: 169
                col: 18
              }
              token: "retval"
            }
          }
          children {
            internalType: "FieldAccessExpr"
            roles: Right
            roles: Condition
            startPosition {
              line: 169
              col: 23
            }
            endPosition {
              line: 169
              col: 49
            }
            children {
              internalType: "NameExpr"
              roles: Scope
              roles: Right
              roles: Condition
              startPosition {
                line: 169
                col: 23
              }
              endPosition {
                line: 169
                col: 34
              }
              children {
                internalType: "SimpleName"
                roles: Scope
                roles: Right
                roles: Condition
                startPosition {
                  line: 169
                  col: 23
                }
                endPosition {
                  line: 169
                  col: 34
                }
                token: "JFileChooser"
              }
            }
            children {
              internalType: "SimpleName"
              roles: Right
              roles: Condition
              roles: Identifier
              startPosition {
                line: 169
                col: 36
              }
              endPosition {
                line: 169
                col: 49
              }
              token: "APPROVE_OPTION"
            }
            token: "FieldAccess:APPROVE_OPTION"
          }
          token: "EQUALS"
        }
        children {
          internalType: "ExpressionStmt"
          roles: Then
          startPosition {
            line: 170
            col: 13
          }
          endPosition {
            line: 170
            col: 42
          }
          children {
            internalType: "AssignExpr"
            roles: Then
            startPosition {
              line: 170
              col: 13
            }
            endPosition {
              line: 170
              col: 41
            }
            children {
              internalType: "NameExpr"
              roles: Then
              roles: Left
              startPosition {
                line: 170
                col: 13
              }
              endPosition {
                line: 170
                col: 13
              }
              children {
                internalType: "SimpleName"
                roles: Then
                roles: Left
                startPosition {
                  line: 170
                  col: 13
                }
                endPosition {
                  line: 170
                  col: 13
                }
                token: "f"
              }
            }
            children {
              internalType: "MethodCallExpr"
              roles: Then
              roles: Right
              startPosition {
                line: 170
                col: 17
              }
              endPosition {
                line: 170
                col: 41
              }
              children {
                internalType: "NameExpr"
                roles: Then
                roles: Callee
                roles: Right
                startPosition {
                  line: 170
                  col: 17
                }
                endPosition {
                  line: 170
                  col: 23
                }
                children {
                  internalType: "SimpleName"
                  roles: Then
                  roles: Callee
                  roles: Right
                  startPosition {
                    line: 170
                    col: 17
                  }
                  endPosition {
                    line: 170
                    col: 23
                  }
                  token: "chooser"
                }
              }
              children {
                internalType: "SimpleName"
                roles: Call
                roles: Then
                roles: Right
                startPosition {
                  line: 170
                  col: 25
                }
                endPosition {
                  line: 170
                  col: 39
                }
                token: "getSelectedFile"
              }
              token: "MethodCall:getSelectedFile"
            }
            token: "ASSIGN"
          }
        }
      }
      children {
        internalType: "ReturnStmt"
        startPosition {
          line: 171
          col: 9
        }
        endPosition {
          line: 171
          col: 17
        }
        children {
          internalType: "NameExpr"
          startPosition {
            line: 171
            col: 16
          }
          endPosition {
            line: 171
            col: 16
          }
          children {
            internalType: "SimpleName"
            startPosition {
              line: 171
              col: 16
            }
            endPosition {
              line: 171
              col: 16
            }
            token: "f"
          }
        }
      }
    }
  }
}
