
package org.jedit.keymap;

/**
 * @author Matthieu Casanova
 * @since jEdit 5.0
 */
public interface Keymap
{
	/**
	 * Returns a shortcut.
	 * @param name the shortcut name
	 * @return the action name or <code>null</code> if there is no shortcut
	 */
	String getShortcut(String name);
	
	/**
	 * Set a new shortcut.
	 * @param name the shortcut name
	 * @param shortcut the action name, or <code>null</code> to delete a 
	 * shortcut
	 */
	void setShortcut(String name, String shortcut);
	
	/**
	 * Save the keymaps.
	 */
	void save();
}

