package com.test;

public class Location {

	
	private static String outputFolderLocation;
	private static String inputFolderLocation;

	public static String getInputFolderLocation() {
		return inputFolderLocation;
	}

	public static void setInputFolderLocation(String inputFolderLocation) {
		Location.inputFolderLocation = inputFolderLocation;
	}

	public static String getOutputFolderLocation() {
		return outputFolderLocation;
	}

	public static void setOutputFolderLocation(String outputFolderLocation) {
		Location.outputFolderLocation = outputFolderLocation;
	}
}

